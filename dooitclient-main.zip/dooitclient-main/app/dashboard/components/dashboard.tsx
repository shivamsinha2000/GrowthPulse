"use client"
import { useEffect, useState } from 'react'
import { Input } from '@/components/ui/input'
import { EmployeeCard, Employee } from './card'
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { PlusCircle, PencilLine, Search } from "lucide-react"
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select"
import { EmployeeExpandedView } from './expanded';
import { useRouter } from 'next/navigation'

type Department = 'All' | 'Development' | 'Data Science' | 'HR' | 'Cloud' | 'DevOps' | 'Quality' | 'Design' | 'Security' | 'Business' | 'AI/ML' | 'Project Mgmt' | 'IT Support' | 'Marketing' | 'Database' | 'Documentation' | 'Architecture' | 'AI/ML' | 'Networking' | 'Product Mgmt' | 'Blockchain' | 'Gaming'

const departments = [
  'All',
  'Development',
  'Data Science',
  'HR',
  'Cloud',
  'DevOps',
  'Quality',
  'Design',
  'Security',
  'Business',
  'AI/ML',
  'Project Mgmt',
  'IT Support',
  'Marketing',
  'Database',
  'Documentation',
  'Architecture',
  'AI/ML',
  'Networking',
  'Product Mgmt',
  'Blockchain',
  'Gaming'
]

export const Dashboard = () => {
    const [selectedDepartment, setSelectedDepartment] = useState<Department>('All')
    const [searchQuery, setSearchQuery] = useState('')
    const [employees, setEmployees] = useState<Employee[]>([])
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
    const router = useRouter()

    useEffect(() => {
        const fetchEmployees = async () => {
          try {
              const response = await fetch('http://localhost:8000/getAllData')
              if (!response.ok) throw new Error('Failed to fetch employees')
              const data = await response.json()
              setEmployees(data)
          } catch (err) {
              setError(err instanceof Error ? err.message : 'Failed to fetch employees')
          } finally {
              setLoading(false)
          }
        }

        fetchEmployees()
    }, [])

    const filteredEmployees = employees.filter(employee => {
      // Filter by department if not "All"
      const matchesDepartment = selectedDepartment === 'All' || 
        employee.Department === selectedDepartment

      // Filter by search query (name)
      const matchesSearch = 
        employee.Name.toLowerCase().includes(searchQuery.toLowerCase())
        
      return matchesDepartment && matchesSearch
    })

    if (loading) {
        return <div className="text-center p-8">Loading employees...</div>
    }

    if (error) {
        return <div className="text-center p-8 text-red-500">Error: {error}</div>
    }

    return (
    <div className="flex flex-col h-screen w-full max-w-[1800px] border-x border-slate-300 bg-gradient-to-br from-slate-50 to-slate-100 shadow-xl mx-auto">
      {/* Header Title */}
      <div className="pt-6 px-8">
        <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
          Employee Dashboard
        </h2>
        <p className="text-slate-500 mt-1">Manage and view all employees</p>
      </div>

      {/* Filters and Actions Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-8 py-5">
        {/* Filters */}
        <div className="flex items-center gap-4 w-full lg:w-auto lg:flex-1 max-w-2xl">
          {/* Department Dropdown */}
          <Select 
            value={selectedDepartment} 
            onValueChange={(value) => setSelectedDepartment(value as Department)}
          >
            <SelectTrigger className="w-[220px] bg-white">
              <SelectValue placeholder="Select Department" />
            </SelectTrigger>
            <SelectContent>
              {departments.map((department) => (
                <SelectItem key={department} value={department}>
                  {department}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          {/* Search Bar */}
          <div className="relative flex-1 min-w-[280px]">
            <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 py-5 bg-white shadow-sm focus-visible:ring-2 focus-visible:ring-blue-300 border-slate-300 focus:border-blue-400"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3 mt-4 lg:mt-0">
          <Button 
            variant="outline"
            className="flex items-center gap-2 bg-white border-slate-300 hover:bg-slate-100 hover:text-blue-700 transition-colors px-4"
            onClick={() => router.push('/views/overview')}
          >
            Overview
          </Button>
          <Button 
            variant="outline" 
            className="flex items-center gap-2 bg-white border-slate-300 hover:bg-slate-100 hover:text-blue-700 transition-colors px-4"
            onClick={() => router.push('/forms/update')}
          >
            <PencilLine className="h-4 w-4" />
            Update Employee
          </Button>
          <Button 
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 transition-colors px-4"
            onClick={() => router.push('/forms/submit')}
          >
            <PlusCircle className="h-4 w-4" />
            Add Employee
          </Button>
        </div>
      </div>

        {/* Employee Grid */}
        <div className="flex-1 px-8 pb-8 overflow-hidden">
          <ScrollArea className="h-[calc(100vh-180px)] w-full pr-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 pb-4 w-full">
              {filteredEmployees.length > 0 ? (
                filteredEmployees.map((employee) => (
                  <div 
                    key={employee.ID} 
                    onClick={() => setSelectedEmployee(employee)}
                    className="cursor-pointer"
                  >
                    <EmployeeCard employee={employee} />
                  </div>
                ))
              ) : (
                <div className="col-span-5 text-center py-16 text-slate-500">
                  No employees found matching your criteria.
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
        
        {/* Employee Expanded View */}
        {selectedEmployee && (
          <EmployeeExpandedView
            employee={selectedEmployee}
            onClose={() => setSelectedEmployee(null)}
          />
        )}
      </div>
  )
}