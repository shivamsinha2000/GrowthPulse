"use client";
import { Button } from "@/components/ui/button";
import { useRouter } from "next/navigation";

export default function Home() {
  const router = useRouter();

  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
      <main className="flex flex-col gap-8 row-start-2 items-center sm:items-start">
        <h1 className="text-3xl font-semibold text-center w-full">
          Team 1 Frontend Demo
        </h1>

        <div
          className="w-full justify-center gap-4 sm:flex mt-4"
        >

            <Button onClick={() => router.push("/login/hr")} 
              className="w-full sm:w-auto font-semibold text-lg h-12"
              >
                Login
            </Button>
        </div>
      </main>
    </div>
  );
}
