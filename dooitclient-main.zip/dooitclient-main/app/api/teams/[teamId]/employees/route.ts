import { NextRequest, NextResponse } from 'next/server'

export async function GET(
  request: NextRequest,
  { params }: { params: { teamId: string } }
) {
  const { mockEmployees } = await import('@/app/api/teams/route')
  const employees = mockEmployees.filter(e => e.teamId === params.teamId)
  return NextResponse.json(employees)
}