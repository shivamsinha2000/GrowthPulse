import React from "react";
import Carousel from "./components/Carousel";

const HomePage: React.FC = () => {
  return (
    <div className="flex justify-center items-center min-h-screen bg-zinc-700">
      <div className="w-[30%] overflow-x-hidden">
        <Carousel />
      </div>
    </div>
  );
};

export default HomePage;