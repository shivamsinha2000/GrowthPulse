// components/employee-expanded-view-content.tsx
import { Employee } from "./card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface SkillGap {
  Skill: string;
  "Employee Proficiency": number;
  "Required Proficiency": number;
  Gap: number;
}

interface SkillGapAnalysis {
  "Employee ID": number;
  "Job Role": string;
  "Recommendations": string[];
  "Skill Gaps": SkillGap[];
}

interface PredictedSkills {
  "Employee ID": number;
  "Skills": Record<string, number>;
}

interface GrowthFactor {
  "Employee ID": number;
  "Growth Factor": number;
  "Job Role": string;
}

interface EmployeeExpandedViewContentProps {
  employee: Employee;
  skillsArray: { name: string; importance: number }[];
  skillGapData: SkillGapAnalysis | null;
  predictedSkills: PredictedSkills | null;
  growthFactor: GrowthFactor | null;
}

export function EmployeeExpandedViewContent({ 
  employee, 
  skillsArray, 
  skillGapData, 
  predictedSkills, 
  growthFactor 
}: EmployeeExpandedViewContentProps) {
  
  // Get performance color based on rating
  const getPerformanceColor = (rating: number) => {
    if (rating >= 4) return "text-emerald-600 bg-emerald-50";
    if (rating >= 3) return "text-blue-600 bg-blue-50";
    if (rating >= 2) return "text-amber-600 bg-amber-50";
    return "text-red-600 bg-red-50";
  }

  // Get growth factor color based on value
  const getGrowthFactorColor = (factor: number) => {
    if (factor >= 25) return "text-emerald-600";
    if (factor >= 20) return "text-blue-600";
    if (factor >= 15) return "text-amber-600";
    return "text-red-600";
  }

  // Convert predicted skills to chart data
  const predictedSkillsData = predictedSkills 
    ? Object.entries(predictedSkills.Skills).map(([skill, level]) => ({ 
        skill, 
        level 
      }))
    : [];

  return (
    <ScrollArea className="flex-1">
      <div className="p-6">
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid grid-cols-4 mb-6">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="skill-gaps">Skill Gaps</TabsTrigger>
            <TabsTrigger value="predicted-skills">Predicted Skills</TabsTrigger>
            <TabsTrigger value="growth">Growth Potential</TabsTrigger>
          </TabsList>
          
          {/* Profile Tab */}
          <TabsContent value="profile" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Information */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Employee Information</CardTitle>
                    <CardDescription>Comprehensive details about {employee.Name}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                      <div>
                        <h4 className="text-sm font-medium text-slate-500">Department</h4>
                        <p className="text-slate-800 mt-1">{employee.Department}</p>
                      </div>
                      <div>
                        <h4 className="text-sm font-medium text-slate-500">Total Experience</h4>
                        <p className="text-slate-800 mt-1">{employee["Total Experience (Years)"]} years</p>
                      </div>
                      {employee["Years in Current Role"] !== undefined && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Current Role Tenure</h4>
                          <p className="text-slate-800 mt-1">{employee["Years in Current Role"]} years</p>
                        </div>
                      )}
                      <div>
                        <h4 className="text-sm font-medium text-slate-500">Education</h4>
                        <p className="text-slate-800 mt-1">{employee.Education}</p>
                      </div>
                      {employee["Performance Rating"] && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Performance Rating</h4>
                          <div className="mt-1">
                            <span className={`text-sm font-medium px-2 py-1 rounded-full ${getPerformanceColor(employee["Performance Rating"])}`}>
                              {employee["Performance Rating"].toFixed(1)} rating
                            </span>
                          </div>
                        </div>
                      )}
                      {employee["Certifications"] !== undefined && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Certifications</h4>
                          <p className="text-slate-800 mt-1">{employee["Certifications"]}</p>
                        </div>
                      )}
                      {employee["Projects Worked On"] !== undefined && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Projects</h4>
                          <p className="text-slate-800 mt-1">{employee["Projects Worked On"]}</p>
                        </div>
                      )}
                      {employee["Trainings Attended"] !== undefined && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Trainings</h4>
                          <p className="text-slate-800 mt-1">{employee["Trainings Attended"]}</p>
                        </div>
                      )}
                      {employee["Previous Roles"] && (
                        <div>
                          <h4 className="text-sm font-medium text-slate-500">Previous Role</h4>
                          <p className="text-slate-800 mt-1">{employee["Previous Roles"]}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Skills Card */}
              <div>
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>Skills</CardTitle>
                    <CardDescription>Key skills and proficiencies</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {skillsArray.map((skill, index) => (
                        <div key={index}>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-medium">{skill.name}</span>
                            <span className="text-sm text-slate-500">
                              Importance: {skill.importance}/10
                            </span>
                          </div>
                          <Progress value={skill.importance * 10} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Skill Gaps Tab */}
          <TabsContent value="skill-gaps" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Skill Gaps Card */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Skill Gap Analysis</CardTitle>
                    <CardDescription>Comparison between current and required skill levels</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {skillGapData?.["Skill Gaps"]?.map((gap, index) => (
                        <div key={index}>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm font-medium">{gap.Skill}</span>
                            <span className="text-sm text-slate-500">
                              Gap: <span className="text-red-500 font-medium">{gap.Gap}</span>
                            </span>
                          </div>
                          <div className="h-6 bg-slate-100 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-blue-600 rounded-full" 
                              style={{ width: `${(gap["Employee Proficiency"]/ 10) * 100}%` }}
                            ></div>
                            
                          </div>
                          <div className="flex justify-between text-xs mt-1">
                            <span>Current: {gap["Employee Proficiency"]}/10</span>
                            <span>Required: {gap["Required Proficiency"]}/10</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Recommendations Card */}
              <div>
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>Recommendations</CardTitle>
                    <CardDescription>Suggested actions for skill improvement</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-4">
                      {skillGapData?.Recommendations?.map((recommendation, index) => (
                        <li key={index} className="flex gap-3">
                          <div className="flex-shrink-0 bg-blue-100 text-blue-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium">
                            {index + 1}
                          </div>
                          <p className="text-sm">{recommendation}</p>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Predicted Skills Tab */}
          <TabsContent value="predicted-skills" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Predicted Skill Proficiency</CardTitle>
                <CardDescription>Anticipated skill development based on current trajectory</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-base font-medium mb-4">Skill Breakdown</h3>
                    <div className="space-y-5">
                      {predictedSkills && Object.entries(predictedSkills.Skills).map(([skill, level], index) => (
                        <div key={index}>
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-medium text-sm">{skill}</span>
                            <span className="text-sm text-slate-600">{level}/10</span>
                          </div>
                          <Progress value={level * 10} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-base font-medium mb-4">Visualization</h3>
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={predictedSkillsData}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} />
                          <XAxis dataKey="skill" />
                          <YAxis domain={[0, 10]} />
                          <Tooltip />
                          <Bar dataKey="level" fill="#3b82f6" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Growth Potential Tab */}
          <TabsContent value="growth" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Growth Potential Analysis</CardTitle>
                    <CardDescription>Career development trajectory based on skills and experience</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-col items-center py-8">
                      <div className="w-48 h-48 rounded-full border-8 border-slate-100 flex items-center justify-center mb-6 relative">
                        <div className="text-center">
                          <div className={`text-4xl font-bold ${getGrowthFactorColor(growthFactor?.["Growth Factor"] || 0)}`}>
                            {growthFactor?.["Growth Factor"].toFixed(1)}
                          </div>
                          <div className="text-slate-500 mt-2">Growth Factor</div>
                        </div>
                      </div>
                      
                      <div className="text-center mt-4 max-w-lg">
                        <h3 className="text-xl font-medium mb-3">What is Growth Factor?</h3>
                        <p className="text-slate-600">
                          Growth Factor is a composite score that reflects an employee's potential for career advancement 
                          based on their skills, experience, and performance. A higher score indicates stronger growth potential.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle>Growth Insights</CardTitle>
                    <CardDescription>Key factors affecting growth potential</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-700 mb-2">Strengths</h4>
                        <ul className="space-y-2 text-sm">
                          <li>• {employee["Skill 1"]} proficiency</li>
                          {employee["Total Experience (Years)"] > 5 && (
                            <li>• Extensive industry experience</li>
                          )}
                          {employee["Performance Rating"] && employee["Performance Rating"] >= 4 && (
                            <li>• Strong performance history</li>
                          )}
                        </ul>
                      </div>
                      
                      <div className="p-4 bg-amber-50 rounded-lg">
                        <h4 className="font-medium text-amber-700 mb-2">Development Areas</h4>
                        <ul className="space-y-2 text-sm">
                          {skillGapData?.["Skill Gaps"]?.[0] && (
                            <li>• {skillGapData["Skill Gaps"]?.[0].Skill} skills enhancement</li>
                          )}
                          {skillGapData?.["Skill Gaps"]?.[1] && (
                            <li>• {skillGapData["Skill Gaps"]?.[1].Skill} knowledge</li>
                          )}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
}