"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useFieldArray, useForm } from "react-hook-form";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useRouter } from "next/navigation"

const departments = [
  "Engineering",
  "Marketing",
  "Human Resources",
  "Finance",
  "Sales",
  "Information Technology",
  "Operations",
  "Customer Support",
  "Research & Development",
  "Legal"
];

const formSchema = z.object({
  name: z.string().nonempty("Name is required"),
  jobtitle: z.string().nonempty("Job title is required"),
  skills: z.array(z.object({
    title: z.string().nonempty("List of skills is required")
  })),
  experience: z.string().nonempty("Experience is required"),
  education: z.string().nonempty("Education is required"),
});

export const ProfileForm = () => {
  const [error, setError] = useState<string | null>(null)
  const router  = useRouter();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { 
      name: "",
      jobtitle: "",
      skills: [],
      experience: "",
      education: "",
    }
  });

  const { fields, append, remove } = useFieldArray({
    name: "skills",
    control: form.control,
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {

      // constructu a json 
      const employee = {
        id: Math.floor(Math.random() * 1000000),
        name: values.name,
        job_title: values.jobtitle,
        skills: values.skills.map(skill => skill.title),
        experience: values.experience,
        education: values.education
      }

      try {
          const response = await fetch('http://localhost:8000/addEmployee', 
            { 
              method: 'POST', 
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(employee)
            }
          )
          if (!response.ok) throw new Error('Failed to fetch employees')
      } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to fetch employees')
      } 

      router.push('/dashboard')
  }

  return (
    <>
      <title>Submit Profile</title>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} 
          className="space-y-8 rounded-md shadow-lg 
            p-8 w-full min-w-[400px] 
            mx-auto my-auto
            bg-[#f9f9f9]
            text-2xl
            justify-items-center"
        >
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem className="space-y-4 min-w-[350px] min-h-[50px]">
                <FormLabel className="text-lg">Employee Name</FormLabel>
                <FormControl>
                  <Input 
                    className="text-lg h-12"
                    placeholder="Enter name"
                    {...field} 
                  />
                </FormControl>
                <FormDescription>
                  This is the legal name of the employee.
                </FormDescription>
                <FormMessage/>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="jobtitle"
            render={({ field }) => (
              <FormItem className="space-y-4 min-w-[350px] min-h-[50px]">
                <FormLabel className="text-lg">Job Title</FormLabel>
                <FormControl>
                  <Input 
                    className="text-lg h-12"
                    placeholder="Enter job title" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage/>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="experience"
            render={({ field }) => (
              <FormItem className="space-y-4 min-w-[350px] min-h-[50px]">
                <FormLabel className="text-lg">Years of Experience</FormLabel>
                <FormControl>
                  <Input 
                    className="text-lg h-12"
                    placeholder="Enter years of experience" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage/>
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="education"
            render={({ field }) => (
              <FormItem className="space-y-4 min-w-[350px] min-h-[50px]">
                <FormLabel className="text-lg">Education</FormLabel>
                <FormControl>
                  <Input 
                    className="text-lg h-12"
                    placeholder="Enter level of education" 
                    {...field} 
                  />
                </FormControl>
                <FormMessage/>
              </FormItem>
            )}
          />
        <div className="space-y-4">
          {fields.map((field, index) => (
            <FormField
              key={field.id}
              control={form.control}
              name={`skills.${index}.title`}
              render={({ field }) => (
                <FormItem className="space-y-4 min-w-[350px]">
                  <div className="flex gap-2 items-center">
                    <FormControl>
                      <Input
                        className="text-lg h-12"
                        placeholder={`Skill#${index + 1}`}
                        {...field}
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant="destructive"
                      onClick={() => remove(index)}
                      className="h-12"
                    >
                      Remove
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => append({ title: "" })}
            className="mt-4"
          >
            Add skill
          </Button>
        </div>
          <Button type="submit" className="w-full h-12 text-lg">
            Submit
          </Button>
        </form>
      </Form>
    </>
  );
}