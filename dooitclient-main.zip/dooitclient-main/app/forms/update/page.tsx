import { EmployeeSkillForm } from "./components/form";

export default function ProfileCreation() {

    return (
        <div className="grid grid-rows-[100px_1fr] justify-items-center min-h-screen p-8 sm:p-20 font-[family-name:var(--font-geist-sans)]"
            >
            <header>
                <h1 className="text-3xl text-center 
                font-semibold
                "
                >
                    Update Employee Skills
                </h1>
            </header>
            <main>
                <EmployeeSkillForm/>
            </main>
        </div>
    );
}