"use client";

import React, { useState } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";

interface Employee {
  id: string;
  name: string;
  agreeableness: number;
  extraversion: number;
  openness: number;
  conscientiousness: number;
  neuroticism: number;
}

interface TeamMember {
  name: string;
  role: string;
  avatar?: string;
}

export default function PersonalityTestPage() {
  const [sortField, setSortField] = useState<keyof Employee | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

  // Reduced mock data for employees (removed 3 rows)
  const employees: Employee[] = [
    {
      id: "1",
      name: "Chris Gonzalez",
      agreeableness: 67,
      extraversion: 67,
      openness: 98,
      conscientiousness: 22,
      neuroticism: 67,
    },
    {
      id: "2",
      name: "Emma Jackson",
      agreeableness: 89,
      extraversion: 89,
      openness: 43,
      conscientiousness: 33,
      neuroticism: 89,
    },
    {
      id: "3",
      name: "Michael Jones",
      agreeableness: 22,
      extraversion: 22,
      openness: 54,
      conscientiousness: 44,
      neuroticism: 22,
    },
    {
      id: "5",
      name: "Robert Chen",
      agreeableness: 78,
      extraversion: 45,
      openness: 87,
      conscientiousness: 92,
      neuroticism: 12,
    },
    {
      id: "8",
      name: "Olivia Martinez",
      agreeableness: 52,
      extraversion: 63,
      openness: 84,
      conscientiousness: 71,
      neuroticism: 36,
    }
  ];

  // Team information with real names for selected employee
  const teamMembers: TeamMember[] = [
    { name: "Jordan Lee", role: "HR" },
    { name: "Sophia Kim", role: "Manager" },
    { name: "David Patel", role: "Lead" },
  ];

  // Colors for personality traits
  const traitColors = {
    openness: "#E3B5B5",      // Light Pink
    neuroticism: "#E6C3E6",   // Purple
    conscientiousness: "#C8E6C8", // Green
    agreeableness: "#C3DFF0", // Blue/Green
    extraversion: "#B5D8E3",  // Light Blue
  };

  // Handle sorting
  const handleSort = (field: keyof Employee) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Sort the employees based on sort field and direction
  const sortedEmployees = [...employees].sort((a, b) => {
    if (!sortField) return 0;
    
    const aValue = a[sortField];
    const bValue = b[sortField];
    
    if (sortDirection === "asc") {
      return typeof aValue === "number" && typeof bValue === "number" 
        ? aValue - bValue 
        : String(aValue).localeCompare(String(bValue));
    } else {
      return typeof aValue === "number" && typeof bValue === "number" 
        ? bValue - aValue 
        : String(bValue).localeCompare(String(aValue));
    }
  });

  // When a row is clicked, select that employee
  const handleRowClick = (employee: Employee) => {
    setSelectedEmployee(employee);
  };

  // Get sort icon for column header
  const getSortIcon = (field: keyof Employee) => {
    if (sortField !== field) return null;
    return sortDirection === "asc" ? <ChevronUp className="h-4 w-4 inline ml-1" /> : <ChevronDown className="h-4 w-4 inline ml-1" />;
  };

  // Create avatar placeholder with initials
  const getInitials = (name: string) => {
    return name.split(' ').map(part => part[0]).join('').slice(0, 2);
  };

  // Calculate the sector angles based on trait values
  const calculatePersonalitySectors = (employee: Employee) => {
    const total = employee.openness + employee.neuroticism + employee.conscientiousness + employee.agreeableness + employee.extraversion;
    
    // Calculate proportions
    const opennessProportion = employee.openness / total;
    const neuroticismProportion = employee.neuroticism / total;
    const conscientiousnessProportion = employee.conscientiousness / total;
    const agreeablenessProportion = employee.agreeableness / total;
    const extraversionProportion = employee.extraversion / total;
    
    // Calculate angles (in radians)
    const opennessAngle = opennessProportion * 2 * Math.PI;
    const neuroticismAngle = neuroticismProportion * 2 * Math.PI;
    const conscientiousnessAngle = conscientiousnessProportion * 2 * Math.PI;
    const agreeablenessAngle = agreeablenessProportion * 2 * Math.PI;
    const extraversionAngle = extraversionProportion * 2 * Math.PI;
    
    // Calculate paths for each sector
    const radius = 40; // SVG radius
    const centerX = 50;
    const centerY = 50;
    
    // Start angles
    let currentAngle = 0;
    
    const polarToCartesian = (angle: number) => {
      return {
        x: centerX + radius * Math.cos(angle - Math.PI / 2),
        y: centerY + radius * Math.sin(angle - Math.PI / 2)
      };
    };
    
    // Generate pie slices
    const createSector = (startAngle: number, endAngle: number) => {
      const start = polarToCartesian(startAngle);
      const end = polarToCartesian(endAngle);
      const largeArcFlag = endAngle - startAngle > Math.PI ? 1 : 0;
      
      return {
        path: `M ${centerX} ${centerY} L ${start.x} ${start.y} A ${radius} ${radius} 0 ${largeArcFlag} 1 ${end.x} ${end.y} Z`,
        midAngle: (startAngle + endAngle) / 2
      };
    };
    
    const opennessSector = createSector(currentAngle, currentAngle + opennessAngle);
    currentAngle += opennessAngle;
    
    const neuroticismSector = createSector(currentAngle, currentAngle + neuroticismAngle);
    currentAngle += neuroticismAngle;
    
    const conscientiousnessSector = createSector(currentAngle, currentAngle + conscientiousnessAngle);
    currentAngle += conscientiousnessAngle;
    
    const agreeablenessSector = createSector(currentAngle, currentAngle + agreeablenessAngle);
    currentAngle += agreeablenessAngle;
    
    const extraversionSector = createSector(currentAngle, currentAngle + extraversionAngle);
    
    return {
      openness: { 
        sector: opennessSector,
        value: employee.openness
      },
      neuroticism: { 
        sector: neuroticismSector,
        value: employee.neuroticism
      },
      conscientiousness: { 
        sector: conscientiousnessSector,
        value: employee.conscientiousness
      },
      agreeableness: { 
        sector: agreeablenessSector,
        value: employee.agreeableness
      },
      extraversion: { 
        sector: extraversionSector,
        value: employee.extraversion
      }
    };
  };

  return (
    <div className="p-6 h-full bg-gray-50">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Employee Personality Assessment</h1>
      </div>

      {/* Table of employees */}
      <div className="mb-8 bg-white rounded-lg shadow overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50 text-gray-600 text-sm">
            <tr>
              <th className="py-3 px-4 text-left font-medium w-1/6">Employee Name</th>
              <th 
                className="py-3 px-4 text-left font-medium w-1/6 cursor-pointer"
                onClick={() => handleSort("agreeableness")}
              >
                <span className="flex items-center">
                  Agreeableness
                  <span className="w-4 h-4 ml-1">{getSortIcon("agreeableness")}</span>
                </span>
              </th>
              <th 
                className="py-3 px-4 text-left font-medium w-1/6 cursor-pointer"
                onClick={() => handleSort("extraversion")}
              >
                <span className="flex items-center">
                  Extraversion
                  <span className="w-4 h-4 ml-1">{getSortIcon("extraversion")}</span>
                </span>
              </th>
              <th 
                className="py-3 px-4 text-left font-medium w-1/6 cursor-pointer"
                onClick={() => handleSort("openness")}
              >
                <span className="flex items-center">
                  Openness
                  <span className="w-4 h-4 ml-1">{getSortIcon("openness")}</span>
                </span>
              </th>
              <th 
                className="py-3 px-4 text-left font-medium w-1/6 cursor-pointer"
                onClick={() => handleSort("conscientiousness")}
              >
                <span className="flex items-center">
                  Conscientiousness
                  <span className="w-4 h-4 ml-1">{getSortIcon("conscientiousness")}</span>
                </span>
              </th>
              <th 
                className="py-3 px-4 text-left font-medium w-1/6 cursor-pointer"
                onClick={() => handleSort("neuroticism")}
              >
                <span className="flex items-center">
                  Neuroticism
                  <span className="w-4 h-4 ml-1">{getSortIcon("neuroticism")}</span>
                </span>
              </th>
            </tr>
          </thead>
          <tbody>
            {sortedEmployees.map((employee) => (
              <tr 
                key={employee.id}
                onClick={() => handleRowClick(employee)}
                className={`border-t hover:bg-gray-50 cursor-pointer ${
                  selectedEmployee?.id === employee.id ? "bg-gray-100" : ""
                }`}
              >
                <td className="py-3 px-4 flex items-center">
                  <span className="inline-block mr-2">◇</span>
                  {employee.name}
                </td>
                <td className="py-3 px-4">{employee.agreeableness}</td>
                <td className="py-3 px-4">{employee.extraversion}</td>
                <td className="py-3 px-4">{employee.openness}</td>
                <td className="py-3 px-4">{employee.conscientiousness}</td>
                <td className="py-3 px-4">{employee.neuroticism}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Selected employee details - center aligned with larger chart */}
      {selectedEmployee && (
        <div className="flex flex-col md:flex-row justify-center items-start space-y-12">

          <div className="w-full md:w-1/3 flex flex-col justify-center items-center mt-32">
            <div className="flex items-center mb-6">
              <div className="mr-4">
                <div className="w-24 h-24 rounded-full bg-yellow-300 overflow-hidden flex items-center justify-center text-white text-3xl font-bold cursor-pointer hover:bg-yellow-400">
                  {getInitials(selectedEmployee.name)}
                </div>
              </div>
              <div>
                <h2 className="text-xl font-medium mb-4">{selectedEmployee.name}</h2>
                <div>
                  <h3 className="text-gray-600 mb-3">Team</h3>
                  <div className="space-y-3">
                    {teamMembers.map((member, index) => (
                      <div key={index} className="flex items-center bg-purple-100 p-3 rounded-md cursor-pointer hover:bg-purple-200">
                        <div className="w-8 h-8 rounded-full overflow-hidden mr-3 bg-blue-500 flex items-center justify-center text-white text-xs font-bold">
                          {getInitials(member.name)}
                        </div>
                        <div>
                          <div className="font-medium">{member.name}</div>
                          <div className="text-xs text-gray-500">{member.role}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Chart and legend in a flex container */}
          <div className="w-full md:w-2/3 flex justify-center">
            <div className="flex flex-col md:flex-row items-center justify-center w-full">
              {/* Chart container - enlarged */}
              <div className="w-full md:w-full flex justify-center">
                {selectedEmployee && (
                  <svg viewBox="0 0 100 100" className="w-full max-w-lg h-auto">
                    {(() => {
                      const sectors = calculatePersonalitySectors(selectedEmployee);
                      
                      return (
                        <>
                          {/* Openness Section - Light Pink */}
                          <path 
                            d={sectors.openness.sector.path} 
                            fill={traitColors.openness} 
                            stroke="white" 
                            strokeWidth="1" 
                          />
                          
                          {/* Neuroticism Section - Purple */}
                          <path 
                            d={sectors.neuroticism.sector.path} 
                            fill={traitColors.neuroticism} 
                            stroke="white" 
                            strokeWidth="1" 
                          />
                          
                          {/* Conscientiousness Section - Green */}
                          <path 
                            d={sectors.conscientiousness.sector.path} 
                            fill={traitColors.conscientiousness} 
                            stroke="white" 
                            strokeWidth="1" 
                          />
                          
                          {/* Agreeableness Section - Blue/Green */}
                          <path 
                            d={sectors.agreeableness.sector.path} 
                            fill={traitColors.agreeableness} 
                            stroke="white" 
                            strokeWidth="1" 
                          />
                          
                          {/* Extraversion Section - Light Blue */}
                          <path 
                            d={sectors.extraversion.sector.path} 
                            fill={traitColors.extraversion} 
                            stroke="white" 
                            strokeWidth="1" 
                          />
                          
                          {/* Center white circle */}
                          <circle cx="50" cy="50" r="15" fill="white" />
                        </>
                      );
                    })()}
                  </svg>
                )}
              </div>
              
              {/* Legend container - vertical list on the right */}
              <div className="w-full md:w-full mt-4 md:mt-0 md:ml-6 flex justify-center md:justify-start">
                <div className="space-y-4">
                  {Object.entries(traitColors).map(([trait, color]) => (
                    <div key={trait} className="flex items-center">
                      <div 
                        className="w-6 h-6 mr-3 rounded" 
                        style={{ backgroundColor: color }}
                      ></div>
                      <div className="flex flex-col">
                        <span className="text-sm font-medium capitalize">{trait}</span>
                        <span className="text-lg font-bold">{selectedEmployee?.[trait as keyof Employee]}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}