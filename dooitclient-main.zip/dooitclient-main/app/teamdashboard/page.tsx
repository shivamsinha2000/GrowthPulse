// dashboard.tsx
"use client"
import { useEffect, useState } from 'react'
import { Input } from '@/components/ui/input'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { TeamCard, Team } from './components/card'
import { EmployeeCard, Employee } from '../dashboard/components/card'
import { ScrollArea } from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"

type Department = 
  'All' | 
  'Business Marketing' |
  'Project Management' |
  'Human Resources' |
  'Development' |
  'Customer Support'

const departments = [
  'All', 
  'Business Marketing', 
  'Project Management', 
  'Human Resources', 
  'Development', 
  'Customer Support'
]

export default function Dashboard() {
    const [selectedDepartment, setSelectedDepartment] = useState<Department>('All')
    const [searchQuery, setSearchQuery] = useState('')
    const [teams, setTeams] = useState<Team[]>([])
    const [employees, setEmployees] = useState<Employee[]>([])
    const [selectedTeam, setSelectedTeam] = useState<string | null>(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {
        const fetchTeams = async () => {
          try {
              const response = await fetch('/api/teams')
              if (!response.ok) throw new Error('Failed to fetch teams')
              const data = await response.json()
              setTeams(data)
          } catch (err) {
              setError(err instanceof Error ? err.message : 'Failed to fetch teams')
          } finally {
              setLoading(false)
          }
        }
        fetchTeams()
    }, [])

    const handleTeamClick = async (teamId: string) => {
        setLoading(true)
        try {
            const response = await fetch(`/api/teams/${teamId}/employees`)
            if (!response.ok) throw new Error('Failed to fetch employees')
            const data = await response.json()
            setEmployees(data)
            setSelectedTeam(teamId)
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch employees')
        } finally {
            setLoading(false)
        }
    }

    const filteredTeams = teams.filter(team => {
      const matchesDepartment = selectedDepartment === 'All' || 
        team.department === selectedDepartment
      
      const matchesSearch = 
        team.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
        team.teamLead.toLowerCase().includes(searchQuery.toLowerCase())

      return matchesDepartment && matchesSearch
    })

    return (
    <div className="flex justify-center items-center min-h-screen p-4">
      <div className="flex h-[85vh] w-full max-w-[1400px] border border-slate-300 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 shadow-xl">
        {/* Departments Sidebar */}
        <div className="w-56 border-r border-slate-300 p-4 bg-slate-100 rounded-l-xl">
          <h2 className="text-2xl font-bold mb-4 pb-5 pt-3 border-b border-slate-300 text-slate-800 text-center tracking-tight">
            Dashboard
          </h2>
          <Tabs orientation="vertical" defaultValue="All">
            <TabsList className="flex flex-col items-start h-auto bg-transparent gap-2">
              {( departments as Department[]).map((department) => (
                <TabsTrigger
                  key={department}
                  value={department}
                  onClick={() => {
                    setSelectedDepartment(department)
                    setSelectedTeam(null)
                  }}
                  className="w-full justify-start data-[state=active]:bg-blue-100 data-[state=active]:text-blue-800 px-3 py-2.5 text-base rounded-lg transition-colors hover:bg-slate-200/80 hover:text-slate-900"
                >
                  {department}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col p-6">
          {/* Header Section */}
          <div className="mb-8 flex items-center justify-between">
            {selectedTeam ? (
              <Button 
                onClick={() => setSelectedTeam(null)}
                variant="ghost"
                className="gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Back to Teams
              </Button>
            ) : (
              <Input
                placeholder="Search teams..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="text-base py-5 shadow-sm focus-visible:ring-2 focus-visible:ring-blue-300 border-slate-300 focus:border-blue-400"
              />
            )}
          </div>

          {/* Content Section */}
          <div className="flex-1 flex flex-col overflow-hidden">
            <ScrollArea className="h-[calc(100vh-180px)] w-full pr-4">
              {selectedTeam ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-4">
                  {employees.map((employee) => (
                    <EmployeeCard 
                      key={employee.id} 
                      employee={employee}
                    />
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 gap-6 pb-4">
                  {filteredTeams.map((team) => (
                    <TeamCard 
                      key={team.id} 
                      team={team}
                      onClick={() => handleTeamClick(team.id)}
                    />
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        </div>
      </div>
    </div>
  )
}