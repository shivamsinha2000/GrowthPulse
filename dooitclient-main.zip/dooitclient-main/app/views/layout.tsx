"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter, usePathname } from "next/navigation";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  CircleUser, 
  Layers, 
  FileText, 
  GitFork, 
  BarChart3, 
  Settings, 
  Lock 
} from "lucide-react";

/** Nav items that we’ll render in the left sidebar. 
 *  ‘id’ matches the subfolder name under /view (overview, skillset, etc.) 
 */
const navItems = [
  { id: "overview",      label: "Overview",         icon: <CircleUser className="h-5 w-5" /> },
  { id: "skillset",      label: "Skill Set",        icon: <Layers className="h-5 w-5" /> },
  { id: "personality", label: "Personality Test", icon: <FileText className="h-5 w-5" /> },
  { id: "career",        label: "Career Path",      icon: <GitFork className="h-5 w-5" /> },
  { id: "report",        label: "Report Dashboard", icon: <BarChart3 className="h-5 w-5" /> },
  { id: "profile",       label: "Profile Settings", icon: <Settings className="h-5 w-5" /> },
  { id: "access",        label: "Access Settings",  icon: <Lock className="h-5 w-5" /> },
];

export default function ViewLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [navOpen, setNavOpen] = useState(true);
  const router = useRouter();
  const pathname = usePathname();

  // e.g. pathname could be "/view/overview", so activePage = "overview"
  const activePage = pathname?.split("/")[2] ?? "overview";

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Left sidebar navigation */}
      {navOpen && (
        <div className="w-64 bg-white border-r border-gray-200 p-4 flex flex-col">
          <div
            className="mb-8 cursor-pointer"
            onClick={() => {
              // Example: go home or do something
              router.push("/");
            }}
          >
            {/* Logo */}
            <Image
              src={"/logo/gphorizontal.png"}
              alt="logo"
              height={300}
              width={300}
            />
          </div>

          <div className="mb-4">
            <p className="text-gray-500 text-sm mb-2">Dashboard</p>
            {/* The first 5 nav items → overview, skillset, personalitytest, career, report */}
            {navItems.slice(0, 5).map((item) => (
              <div
                key={item.id}
                className={`flex items-center p-2 my-1 rounded-md cursor-pointer hover:bg-gray-100 ${
                  activePage === item.id ? "bg-gray-200" : ""
                }`}
                onClick={() => router.push(`/views/${item.id}`)}
              >
                <span className="mr-2 text-gray-600">{item.icon}</span>
                <span>{item.label}</span>
              </div>
            ))}
          </div>

          <div>
            <p className="text-gray-500 text-sm mb-2">Settings</p>
            {/* The last 2 nav items → profile, access */}
            {navItems.slice(5).map((item) => (
              <div
                key={item.id}
                className={`flex items-center p-2 my-1 rounded-md cursor-pointer hover:bg-gray-100 ${
                  activePage === item.id ? "bg-gray-200" : ""
                }`}
                onClick={() => router.push(`/views/${item.id}`)}
              >
                <span className="mr-2 text-gray-600">{item.icon}</span>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main content area */}
      <div className="flex-1 overflow-auto">
        {/* Top navigation */}
        <div className="bg-white p-4 border-b flex items-center justify-between">
          <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={() => setNavOpen(!navOpen)}>
              {/* Just use an emoji or icon for toggling */}
              {navOpen ? "📑" : "📑"}
            </Button>
            <span className="mx-2">/</span>
            <span>
              {navItems.find((item) => item.id === activePage)?.label}
            </span>
          </div>

          <div className="flex items-center">
            <div className="relative mr-4">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input placeholder="Search..." className="pl-10 w-64 rounded-full" />
            </div>

            <div className="flex items-center">
              <div className="w-8 h-8 bg-orange-300 rounded-full flex items-center justify-center text-white mr-2">
                A
              </div>
              <div>
                <div className="font-medium">Ava</div>
                <div className="text-xs text-gray-500">Tech Manager</div>
              </div>
            </div>
          </div>
        </div>

        {/* The actual page content goes here */}
        {children}
      </div>
    </div>
  );
}