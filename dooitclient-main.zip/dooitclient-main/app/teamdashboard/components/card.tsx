"use client"
import { Card } from "@/components/ui/card"

export interface Team {
  id: string
  department: string
  teamLead: string
  employeeCount: number
  memberTitles: string[]
  currentProjects: number
}

interface TeamCardProps {
  team: Team
  onClick: () => void
}


export function TeamCard({ team, onClick }: TeamCardProps) {
  return (
    <Card 
      onClick={onClick}
      className="p-6 hover:shadow-md transition-all h-full min-w-[320px] bg-white border-slate-100 cursor-pointer hover:border-blue-200"
    >

      <h3 className="font-bold text-xl mb-3 text-slate-800">{team.department}</h3>
      
      <div className="space-y-4">
        <div>
          <p className="text-md font-medium text-slate-600">Team Lead:</p>
          <p className="text-lg text-slate-700">{team.teamLead}</p>
        </div>

        <div className="flex gap-6">
          <div>
            <p className="text-md font-medium text-slate-600">Members</p>
            <p className="text-2xl font-bold text-blue-600">{team.employeeCount}</p>
          </div>
          <div>
            <p className="text-md font-medium text-slate-600">Projects</p>
            <p className="text-2xl font-bold text-green-600">{team.currentProjects}</p>
          </div>
        </div>

        <div>
          <p className="text-md font-medium mb-2 text-slate-600">Key Roles:</p>
          <div className="flex flex-wrap gap-2">
            {team.memberTitles.slice(0,4).map((title, index) => (
              <span 
                key={index}
                className="text-sm bg-slate-100 text-slate-700 px-3 py-1.5 rounded-full"
              >
                {title}
              </span>
            ))}
          </div>
        </div>

        <div className="pt-4 border-t border-slate-100">
          <p className="text-sm text-slate-500">
            {team.memberTitles.length > 4 ? 
              `+ ${team.memberTitles.length - 4} more roles` : 
              'All roles shown'}
          </p>
        </div>
      </div>
    </Card>
  )
}