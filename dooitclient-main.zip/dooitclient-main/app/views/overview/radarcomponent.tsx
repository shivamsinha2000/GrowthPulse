import { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, Radar, Legend, Tooltip } from 'recharts';

// Define types for API data
type SkillGap = {
  Employee_Proficiency: number;
  Gap: number;
  Required_Proficiency: number;
  Skill: string;
};

type Employee = {
  'Employee ID': number;
  'Growth Factor': number;
  'Skill Gaps': SkillGap[];
};

// Type for radar chart data
type RadarDataPoint = {
  subject: string;
  proficiency: number;
  gap: number;
  fullMark: number;
};

const EmployeeSkillsRadar = () => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  useEffect(() => {
    const fetchEmployeeData = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:8000/getEmployeeStats');
        if (!response.ok) {
          throw new Error('Failed to fetch employee data');
        }
        const data = await response.json();
        setEmployees(data);
        
        // Set the first employee as default selected
        if (data.length > 0) {
          setCurrentEmployee(data[0]);
        }
        
        setLoading(false);
      } catch (err) {
        setFetchError(err instanceof Error ? err.message : 'Unknown error');
        setLoading(false);
      }
    };

    fetchEmployeeData();
  }, []);

  // Transform skill data for radar chart
  const prepareRadarData = (employee: Employee | null): RadarDataPoint[] => {
    if (!employee || !employee['Skill Gaps']) return [];
    
    return employee['Skill Gaps'].map(skill => ({
      subject: skill.Skill,
      proficiency: skill['Employee_Proficiency'],
      gap: skill.Gap,
      fullMark: skill['Required_Proficiency']
    }));
  };

  // Calculate employee's overall proficiency percentage
  const calculateProficiencyPercentage = (employee: Employee | null): number => {
    if (!employee || !employee['Skill Gaps'] || employee['Skill Gaps'].length === 0) return 0;
    
    const totalProficiency = employee['Skill Gaps'].reduce((sum, skill) => 
      sum + skill['Employee_Proficiency'], 0);
    const totalRequired = employee['Skill Gaps'].reduce((sum, skill) => 
      sum + skill['Required_Proficiency'], 0);
    
    return Math.round((totalProficiency / totalRequired) * 100);
  };

  // Get top skills and gaps for selected employee
  const getTopSkill = (employee: Employee | null): SkillGap | null => {
    if (!employee || !employee['Skill Gaps'] || employee['Skill Gaps'].length === 0) return null;
    
    return employee['Skill Gaps'].reduce((top, skill) => 
      skill['Employee_Proficiency'] > top['Employee_Proficiency'] ? skill : top, 
      employee['Skill Gaps'][0]);
  };

  const getBiggestGap = (employee: Employee | null): SkillGap | null => {
    if (!employee || !employee['Skill Gaps'] || employee['Skill Gaps'].length === 0) return null;
    
    return employee['Skill Gaps'].reduce((biggest, skill) => 
      skill.Gap > biggest.Gap ? skill : biggest, 
      employee['Skill Gaps'][0]);
  };

  if (loading) return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-center items-center h-64">
          <p>Loading employee data...</p>
        </div>
      </CardContent>
    </Card>
  );

  if (fetchError) return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-center items-center h-64">
          <p className="text-red-500">Error: {fetchError}</p>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Employee Skill Analysis</CardTitle>
          <Select 
            value={currentEmployee ? currentEmployee['Employee ID'].toString() : ''} 
            onValueChange={(value) => {
              const employee = employees.find(emp => emp['Employee ID'].toString() === value);
              setCurrentEmployee(employee || null);
            }}
          >
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select Employee" />
            </SelectTrigger>
            <SelectContent>
              {employees.map((employee) => (
                <SelectItem 
                  key={employee['Employee ID']} 
                  value={employee['Employee ID'].toString()}
                >
                  Employee #{employee['Employee ID']}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {currentEmployee && (
          <div className="flex flex-col lg:flex-row w-full gap-6">
            {/* Left side - Radar chart */}
            <div className="w-full lg:w-2/3">
              <h3 className="text-lg font-medium mb-4">
                Employee #{currentEmployee['Employee ID']} - Skill Radar
              </h3>
              <div className="h-96 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart 
                    cx="50%" 
                    cy="50%" 
                    outerRadius="80%" 
                    data={prepareRadarData(currentEmployee)}
                  >
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <Tooltip />
                    <Radar 
                      name="Proficiency" 
                      dataKey="proficiency" 
                      stroke="#2563eb" 
                      fill="#3b82f6" 
                      fillOpacity={0.6} 
                    />
                    <Radar 
                      name="Gap" 
                      dataKey="gap" 
                      stroke="#ef4444" 
                      fill="#f87171" 
                      fillOpacity={0.6} 
                    />
                    <Legend />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Right side - Stats */}
            <div className="w-full lg:w-1/3 space-y-6">
              <div className="bg-gray-100 p-4 rounded-lg">
                <h3 className="text-lg font-medium mb-2">Performance Overview</h3>
                <div className="flex flex-col gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Overall Proficiency</p>
                    <div className="flex items-center gap-2">
                      <div className="w-full bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-blue-600 h-4 rounded-full" 
                          style={{ width: `${calculateProficiencyPercentage(currentEmployee)}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-medium">{calculateProficiencyPercentage(currentEmployee)}%</span>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500">Growth Factor</p>
                    <p className="text-xl font-bold">{currentEmployee['Growth Factor'].toFixed(1)}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="text-sm text-blue-700 font-medium">Top Skill</h4>
                  {getTopSkill(currentEmployee) && (
                    <div className="mt-2">
                      <p className="text-lg font-bold">{getTopSkill(currentEmployee)?.Skill}</p>
                      <p className="text-sm">
                        Proficiency: {getTopSkill(currentEmployee)?.['Employee_Proficiency']} / 
                        {getTopSkill(currentEmployee)?.['Required_Proficiency']}
                      </p>
                    </div>
                  )}
                </div>

                <div className="bg-red-50 p-4 rounded-lg">
                  <h4 className="text-sm text-red-700 font-medium">Biggest Gap</h4>
                  {getBiggestGap(currentEmployee) && (
                    <div className="mt-2">
                      <p className="text-lg font-bold">{getBiggestGap(currentEmployee)?.Skill}</p>
                      <p className="text-sm">
                        Gap: {getBiggestGap(currentEmployee)?.Gap} points
                        (Currently: {getBiggestGap(currentEmployee)?.['Employee_Proficiency']} / 
                        {getBiggestGap(currentEmployee)?.['Required_Proficiency']})
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-gray-100 p-4 rounded-lg">
                <h4 className="text-sm font-medium mb-2">All Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {currentEmployee['Skill Gaps'].map((skill, index) => (
                    <Badge key={index} variant={skill.Gap > 3 ? "destructive" : "outline"}>
                      {skill.Skill}: {skill['Employee_Proficiency']}/{skill['Required_Proficiency']}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default EmployeeSkillsRadar;