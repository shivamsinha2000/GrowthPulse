import React from 'react';
import styles from './InfiniteCarousel.module.css';

const dummyItems = [
  { id: 1, title: 'Card 1', description: 'Description 1' },
  { id: 2, title: 'Card 2', description: 'Description 2' },
  { id: 3, title: 'Card 3', description: 'Description 3' },
  { id: 4, title: 'Card 4', description: 'Description 4' },
  { id: 5, title: 'Card 5', description: 'Description 1' },
  { id: 6, title: 'Card 6', description: 'Description 2' },
  { id: 7, title: 'Card 7', description: 'Description 3' },
  { id: 8, title: 'Card 8', description: 'Description 4' },
];

const InfiniteCarousel = () => {
  return (
    <div className={styles.carouselContainer}>
      <div className={styles.carouselTrack}>
        {/* Original set */}
        {dummyItems.map((item) => (
          <div key={item.id} className={styles.carouselItem}>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </div>
        ))}
        {/* Duplicate set */}
        {dummyItems.map((item) => (
          <div key={`dup-${item.id}`} className={styles.carouselItem}>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default InfiniteCarousel;
