// app/api/employees/route.ts
import { NextResponse } from 'next/server'

interface Employee {
  id: string
  name: string
  department: string
  email: string
  skills: string[]
  experience: string
  education: string
}

export async function GET() {
    const employees: Employee[] = [
        {
            id: "1",
            name: "Sarah Johnson",
            department: "Development",
            email: "sarah.johnson@techcorp.com",
            skills: ["JavaScript", "React", "Node.js", "TypeScript"],
            experience: "5+ years building scalable web applications",
            education: "B.S. Computer Science, MIT"
        },
        {
            id: "2",
            name: "Michael Chen",
            department: "Business Marketing",
            email: "michael.chen@techcorp.com",
            skills: ["SEO", "Social Media Strategy", "Market Research", "CRM"],
            experience: "Digital marketing specialist with focus on tech startups",
            education: "MBA, Stanford University"
        },
        {
            id: "3",
            name: "Emma Wilson",
            department: "Human Resources",
            email: "emma.wilson@techcorp.com",
            skills: ["Talent Acquisition", "Employee Relations", "Training & Development"],
            experience: "8 years in HR management and organizational development",
            education: "B.A. Psychology, University of Toronto"
        },
        {
            id: "4",
            name: "Raj Patel",
            department: "Project Management",
            email: "raj.patel@techcorp.com",
            skills: ["Agile Methodologies", "Risk Management", "JIRA", "Budgeting"],
            experience: "Certified PMP with 7 years in IT project management",
            education: "M.S. Information Systems, Carnegie Mellon"
        },
        {
            id: "5",
            name: "Lisa Nguyen",
            department: "Development",
            email: "lisa.nguyen@techcorp.com",
            skills: ["Python", "Machine Learning", "Data Analysis", "SQL"],
            experience: "Data scientist specializing in predictive modeling",
            education: "Ph.D. Artificial Intelligence, ETH Zurich"
        },
        {
            id: "6",
            name: "David Miller",
            department: "Business Marketing",
            email: "david.miller@techcorp.com",
            skills: ["Content Marketing", "Brand Strategy", "Google Analytics"],
            experience: "10 years in B2B marketing and brand positioning",
            education: "B.A. Communications, Northwestern University"
        },
        {
            id: "7",
            name: "Aisha Khan",
            department: "Human Resources",
            email: "aisha.khan@techcorp.com",
            skills: ["Diversity & Inclusion", "Compensation Analysis", "HRIS"],
            experience: "HR business partner with global workforce experience",
            education: "M.A. Labor Relations, Cornell University"
        },
        {
            id: "8",
            name: "James O'Connor",
            department: "Project Management",
            email: "james.oconnor@techcorp.com",
            skills: ["Scrum Master", "Resource Allocation", "Stakeholder Management"],
            experience: "Managed projects for Fortune 500 clients",
            education: "B.Eng. Industrial Engineering, Georgia Tech"
        },
        {
            id: "9",
            name: "Maria Gonzalez",
            department: "Development",
            email: "maria.gonzalez@techcorp.com",
            skills: ["Java", "Spring Boot", "Microservices", "AWS"],
            experience: "Backend developer focused on cloud-native applications",
            education: "M.S. Software Engineering, University of Washington"
        },
        {
            id: "10",
            name: "Olivia Smith",
            department: "Business Marketing",
            email: "olivia.smith@techcorp.com",
            skills: ["Email Marketing", "Conversion Optimization", "A/B Testing"],
            experience: "Growth marketer with SaaS industry expertise",
            education: "B.S. Marketing, University of Pennsylvania"
        },
        {
            id: "11",
            name: "Carlos Mendoza",
            department: "Development",
            email: "carlos.mendoza@techcorp.com",
            skills: ["Go", "Docker", "Kubernetes", "Microservices"],
            experience: "Backend specialist focused on high-performance systems",
            education: "M.Eng. Computer Engineering, ETH Zurich"
        },
        {
            id: "12",
            name: "Sophie Turner",
            department: "Business Marketing",
            email: "sophie.turner@techcorp.com",
            skills: ["E-commerce", "PPC Advertising", "Conversion Rate Optimization"],
            experience: "Digital marketing expert with retail industry focus",
            education: "B.A. Digital Marketing, NYU"
        },
        {
            id: "13",
            name: "Priya Sharma",
            department: "Human Resources",
            email: "priya.sharma@techcorp.com",
            skills: ["Talent Management", "Succession Planning", "HR Analytics"],
            experience: "Global HR strategist with Fortune 500 experience",
            education: "M.S. Organizational Behavior, LSE"
        },
        {
            id: "14",
            name: "Andrei Petrov",
            department: "Project Management",
            email: "andrei.petrov@techcorp.com",
            skills: ["SAFe", "Azure DevOps", "Stakeholder Mapping"],
            experience: "Agile coach implementing scaled frameworks",
            education: "MBA, INSEAD"
        },
        {
            id: "15",
            name: "Liam Chen",
            department: "Development",
            email: "liam.chen@techcorp.com",
            skills: ["Vue.js", "GraphQL", "Web Performance"],
            experience: "Frontend architect optimizing user experiences",
            education: "B.S. Computer Science, UC Berkeley"
        },
        {
            id: "16",
            name: "Fatima Al-Mansoori",
            department: "Business Marketing",
            email: "fatima.mansoori@techcorp.com",
            skills: ["Brand Strategy", "Market Segmentation", "CRM"],
            experience: "Global brand manager expanding into emerging markets",
            education: "MSc International Business, HEC Paris"
        },
        {
            id: "17",
            name: "Ethan James",
            department: "Human Resources",
            email: "ethan.james@techcorp.com",
            skills: ["Compensation Design", "Payroll Systems", "HR Compliance"],
            experience: "Total rewards specialist ensuring competitive packages",
            education: "B.A. Business Administration, UCLA"
        },
        {
            id: "18",
            name: "Dmitry Ivanov",
            department: "Development",
            email: "dmitry.ivanov@techcorp.com",
            skills: ["Rust", "Blockchain", "Cryptography"],
            experience: "Systems programmer building secure infrastructure",
            education: "Ph.D. Computer Science, Moscow State University"
        },
        {
            id: "19",
            name: "Isabella Rossi",
            department: "Project Management",
            email: "isabella.rossi@techcorp.com",
            skills: ["Risk Management", "Budget Forecasting", "MS Project"],
            experience: "IT project manager delivering complex implementations",
            education: "M.S. Information Technology, Politecnico di Milano"
        },
        {
            id: "20",
            name: "Yuki Tanaka",
            department: "Development",
            email: "yuki.tanaka@techcorp.com",
            skills: ["React Native", "Mobile Security", "CI/CD"],
            experience: "Mobile developer creating cross-platform applications",
            education: "B.Eng. Software Engineering, University of Tokyo"
        }
    ];

  return NextResponse.json(employees)
}