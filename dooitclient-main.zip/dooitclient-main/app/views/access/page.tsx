"use client";

export default function PersonalityTestPage() {
  return (
    <div className="flex items-center justify-center h-full">
      <p className="text-3xl font-bold">Not Implemented</p>
    </div>
  );
}
