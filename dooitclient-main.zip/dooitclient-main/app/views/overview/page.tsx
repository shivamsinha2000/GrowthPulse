"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageSquare, Search } from "lucide-react";
import { Employee } from "../../dashboard/components/card"
import { EmployeeExpandedView } from "@/app/dashboard/components/expanded";
import { useRouter } from "next/navigation";
import { get } from "http";
import EmployeeSkillsRadar from "./radarcomponent";
import EmployeeSkillsOverview from "./skilloverview";

// -- Example types
type SkillData = { skill: string; proficient: number; gap: number; };


// Random background color generator
const avatarBgColors = [
  "bg-blue-500", "bg-purple-500", "bg-orange-500", "bg-green-500", 
  "bg-red-500", "bg-pink-500", "bg-yellow-500", "bg-indigo-500", 
  "bg-teal-500", "bg-cyan-500"
];

const getAvatarBgColor = (index: any) => {
  return avatarBgColors[index % avatarBgColors.length];
};

// The main Overview page
export default function OverviewPage() {

    // Team members data with more formal avatars
    const [teamMembers, setTeamMembers] = useState<Employee[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);

    // Add this state for the search functionality
    const [searchQuery, setSearchQuery] = useState("");

    // Add this function to filter employees based on search query
    const filteredEmployees = searchQuery
    ? teamMembers.filter(member => 
        member.Name.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : teamMembers;
      
    const router = useRouter();

    useEffect(() => {
    const fetchTeamMembers = async () => {
      try {
        const response = await fetch('http://localhost:8000/getAllData');
        if (!response.ok) {
          throw new Error('Failed to fetch team members');
        }
        const data = await response.json();
        setTeamMembers(data);
      } catch (err) {
        setError('Error fetching team members');
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTeamMembers();
    }, []);

    // Get first letter of name for avatar
    const getFirstLetter = (name: string) => {
      return name ? name.charAt(0) : '?';
      };

      if (isLoading) {
        return <div>Loading team members...</div>;
      }

      if (error) {
        return <div className="text-red-500">{error}</div>;
    }


  // Top performers
  const topPerformers = ["John", "Emma", "Sunny", "Alex", "Rina"];

  // Required skills
  const requiredSkills = [
    { name: "Power BI", score: 80, color: "green" },
    { name: "Pandas", score: 60, color: "green" },
    { name: "R lang.", score: 20, color: "red" },
    { name: "MongoDB", score: 40, color: "red" },
  ];

  // Course recommendations
  const courses = Array(4).fill({
    title: "Course 1",
    rating: 4,
    duration: "3 Hrs",
  });


  return (
    <div className="p-6">
      <div className="grid grid-cols-4 gap-6">
        {/* LEFT: 3 columns */}
        <div className="col-span-3 space-y-6">




          <EmployeeSkillsOverview />


          {/* 
          <Card>
            <CardHeader>
              <CardTitle>Current Skill Gaps for Ongoing Projects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex w-full gap-6">
                <div className="flex-1 relative">
                  <div className="absolute top-0 right-0 mt-2 mr-2">
                    <Select value={timeDuration} onValueChange={handleDurationChange}>
                      <SelectTrigger className="w-36">
                        <SelectValue placeholder="Time Duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1 month">1 month</SelectItem>
                        <SelectItem value="6 month">6 month</SelectItem>
                        <SelectItem value="1 year">1 year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="h-8"></div>
                  <p className="text-sm font-medium mb-2">Number of Employees</p>

                  <div className="bg-gray-100 p-4 rounded-md">
                    <div className="flex items-end h-72">
                      <div className="w-10 flex flex-col items-end justify-between pr-2 h-60 mb-2 relative">
                        {yAxisLabels.map((label, i) => (
                          <div key={i} className="text-xs text-gray-500 mr-1">
                            {label}
                          </div>
                        ))}
                      </div>

                      <div className="flex-1 relative h-60">
                        {yAxisLabels.map((_, i) => (
                          <div
                            key={i}
                            className="absolute w-full border-t border-gray-200"
                            style={{ bottom: `${i * 20}%` }}
                          />
                        ))}

                        <div className="absolute inset-0 flex justify-between px-2">
                          {skillDataByDuration[timeDuration].map((item, i) => (
                            <div
                              key={i}
                              className="flex flex-col justify-end items-center w-8"
                            >
                              <div
                                className="w-full bg-blue-200"
                                style={{
                                  height: `${(item.gap / 150) * 100}%`,
                                }}
                              />
                              <div
                                className="w-full bg-blue-600"
                                style={{
                                  height: `${(item.proficient / 150) * 100}%`,
                                }}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex mt-2">
                      <div className="w-10" />
                      <div className="flex-1">
                        <div className="flex justify-between px-2">
                          {skillDataByDuration[timeDuration].map((item, i) => (
                            <span key={i} className="text-xs text-center w-8">
                              {item.skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 text-xs">
                      <div className="flex items-center mb-1">
                        <div className="w-3 h-3 bg-blue-200 mr-1"></div>
                        <span>Skill Gap</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-blue-600 mr-1"></div>
                        <span>Proficient</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="w-1/5 p-6">
                  <p className="text-m font-medium mb-2">Top performers this Month</p>
                  <div className="space-y-7 p-4">
                    {topPerformers.map((name, i) => (
                      <div key={i} className="flex items-center">
                        <span className="font-bold mr-2 text-lg">{i + 1}.</span>
                        <span className="font-bold text-lg">{name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          */}













          <Card>
            <CardHeader>
              <CardTitle>New Skills Required for Upcoming Projects</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {requiredSkills.map((skill, i) => {
                  const isOver50 = skill.score >= 50;
                  return (
                    <div key={i} className="flex items-center">
                      <span className="font-medium mr-2 w-8">{i + 1}.</span>
                      <span className="w-24">{skill.name}</span>

                      <div className="flex-1 relative">
                        <div
                          className={`h-2 rounded-full ${
                            isOver50 ? "bg-green-400" : "bg-red-400"
                          }`}
                          style={{ width: `${skill.score}%` }}
                        />
                        <div
                          className="absolute -top-6"
                          style={{ left: `${skill.score}%` }}
                        >
                          <div className="relative -translate-x-1/2 text-xs font-semibold flex flex-col items-center">
                            <span>{skill.score}/100</span>
                            <div className="w-0 h-0 border-l-4 border-r-4 border-l-transparent border-r-transparent border-t-4 border-t-black mt-1" />
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Course recommendations */}
          <div>
            <h2 className="text-xl font-bold mb-4">Recommendations for Up-Skilling</h2>
            <div className="grid grid-cols-4 gap-4">
              {courses.map((course, i) => (
                <div
                  key={i}
                  className="bg-pink-100 p-4 rounded-md cursor-pointer hover:shadow-md transition-shadow"
                >
                  <div className="flex justify-center items-center h-32">
                    <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center">
                      <span className="text-pink-500">🎯</span>
                    </div>
                  </div>
                  <div className="flex justify-between mt-4">
                    <div>
                      <p className="font-medium">{course.title}</p>
                      <div className="text-yellow-500">★★★★☆</div>
                    </div>
                    <div className="text-sm">{course.duration}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT: 1 column – Team members */}
        <div className="col-span-1 px-8 py-2">
  <div>
    <div className="flex justify-between items-center mb-4">
      <h2 className="text-xl font-bold">Team Member</h2>
      <Button 
        variant="outline" 
        className="flex items-center gap-1"
        onClick={() => router.push('/dashboard')}
      >
        Detailed Employee Info
      </Button>
    </div>
    
    {/* Search bar */}
    <div className="relative mb-4">
      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
      <Input
        placeholder="Search employees..."
        className="pl-10"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
    </div>
    
        <div className="space-y-4 overflow-y-auto h-[calc(100vh-250px)] thin-scrollbar pr-4">
          {filteredEmployees.map((member) => {
            // Create a memoized background color for consistency in renders
            const avatarBg = getAvatarBgColor(member.ID);
              
              return (
                <div
                  key={member.ID}
                  className="flex items-center justify-between bg-blue-200 p-4 rounded-xl cursor-pointer hover:bg-blue-300 transition-colors"
                  onClick={() => setSelectedEmployee(member)}
                >
                  <div className="flex items-center">
                    <div
                      className={`w-8 h-8 ${avatarBg} rounded-full flex items-center justify-center text-white font-medium mr-2`}
                    >
                      {getFirstLetter(member.Name)}
                    </div>
                    <div>
                      <p className="font-medium text-sm">{member.Name}</p>
                      <p className="text-m text-gray-600">{member["Job Role"]}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" className="h-6 w-6">
                    <MessageSquare className="h-4 w-4" />
                  </Button>
                </div>
              );
            })}
            
            {filteredEmployees.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                No employees found matching "{searchQuery}"
              </div>
            )}
          </div>
        </div>
      </div>
    </div>

    {/* Employee Expanded View */}
      {selectedEmployee && (
        <EmployeeExpandedView
          employee={selectedEmployee}
          onClose={() => setSelectedEmployee(null)}
        />
    )}

    </div>
  );
}