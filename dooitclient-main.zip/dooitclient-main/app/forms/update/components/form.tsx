"use client";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useFieldArray } from "react-hook-form";
import { useEffect, useState } from "react";
import { Employee } from "@/app/dashboard/components/card";
import { useRouter } from "next/navigation";

const formSchema = z.object({
  employee: z.string().nonempty("Please select an employee"),
  skills: z.array(z.object({
    title: z.string().nonempty("List of skills is required")
  })),
});

export const EmployeeSkillForm = () => {

  const [employees, setEmployees] = useState<Employee[]>([])
  const [error, setError] = useState<string | null>(null)
  const [selected, setSelected] = useState(0);
  const router = useRouter();

  useEffect(() => {
    const fetchEmployees = async () => {
      try {
          const response = await fetch('http://localhost:8000/getAllData')
          if (!response.ok) throw new Error('Failed to fetch employees')
          const data = await response.json()
          setEmployees(data)
      } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to fetch employees')
      }
    }

    fetchEmployees()
  }, [])

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      employee: "",
      skills: [],
    }
  });

  const { fields, append, remove } = useFieldArray({
    name: "skills",
    control: form.control,
  });

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    
    const employee = {
      skills: values.skills.map((skill: { title: string }) => skill.title)
    }

    try {
        const response = await fetch('http://localhost:8000/updateEmployee/'+values.employee, 
          { 
            method: 'POST', 
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(employee)
          }
        )
        if (!response.ok) throw new Error('Failed to fetch employees')
    } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch employees')
    } 
    router.push('/dashboard')
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} 
        className="space-y-8 rounded-md shadow-lg 
          p-8 w-full min-w-[400px] 
          mx-auto my-auto
          bg-[#f9f9f9]
          text-2xl
          justify-items-center"
      >
        {/* Employee Selection Dropdown */}
        <FormField
          control={form.control}
          name="employee"
          render={({ field }) => (
            <FormItem className="space-y-4 min-w-[350px] min-h-[50px]">
              <FormLabel className="text-lg">Select Employee</FormLabel>
              <FormControl>
                <select
                  {...field}
                  className="flex h-12 w-full rounded-md border border-input bg-background px-3 py-2 text-lg ring-offset-background"
                >
                  <option value="">Select an employee...</option>
                  {employees.map((employee) => (
                    <option key={employee.id} value={employee.id}>
                      {employee.name} - {employee.job_title}
                    </option>
                  ))}
                </select>
              </FormControl>
              <FormDescription>
                Select an employee from the list
              </FormDescription>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="space-y-4">
          {fields.map((field, index) => (
            <FormField
              key={field.id}
              control={form.control}
              name={`skills.${index}.title`}
              render={({ field }) => (
                <FormItem className="space-y-4 min-w-[350px]">
                  <div className="flex gap-2 items-center">
                    <FormControl>
                      <Input
                        className="text-lg h-12"
                        placeholder={`Skill#${index + 1}`}
                        {...field}
                      />
                    </FormControl>
                    <Button
                      type="button"
                      variant="destructive"
                      onClick={() => remove(index)}
                      className="h-12"
                    >
                      Remove
                    </Button>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          ))}
          <Button
            type="button"
            variant="outline"
            onClick={() => append({ title: "" })}
            className="mt-4"
          >
            Add skill
          </Button>
        </div>

        <Button type="submit" className="w-full h-14 text-lg">
          Submit Skills
        </Button>
      </form>
    </Form>
  );
};