// components/employee-expanded-view.tsx
import { useState, useEffect } from "react";
import { Employee } from "./card";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { EmployeeExpandedViewContent } from "./expandedContent";

interface SkillGap {
  Skill: string;
  "Employee Proficiency": number;
  "Required Proficiency": number;
  Gap: number;
}

interface SkillGapAnalysis {
  "Employee ID": number;
  "Job Role": string;
  "Recommendations": string[];
  "Skill Gaps": SkillGap[];
}

interface PredictedSkills {
  "Employee ID": number;
  "Skills": Record<string, number>;
}

interface GrowthFactor {
  "Employee ID": number;
  "Growth Factor": number;
  "Job Role": string;
}

interface EmployeeExpandedViewProps {
  employee: Employee;
  onClose: () => void;
}

export function EmployeeExpandedView({ employee, onClose }: EmployeeExpandedViewProps) {
  const [skillGapData, setSkillGapData] = useState<SkillGapAnalysis | null>(null);
  const [predictedSkills, setPredictedSkills] = useState<PredictedSkills | null>(null);
  const [growthFactor, setGrowthFactor] = useState<GrowthFactor | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Extract skills as an array with importance
  const skillsArray = [
    { name: employee["Skill 1"], importance: employee["Skill 1 Importance"] },
    { name: employee["Skill 2"], importance: employee["Skill 2 Importance"] },
    { name: employee["Skill 3"], importance: employee["Skill 3 Importance"] }
  ].filter(skill => skill.name);
  
  // Sort skills by importance (highest first)
  const topSkills = skillsArray
    .sort((a, b) => b.importance - a.importance)
    .slice(0, 3)
    .map(skill => skill.name);
  
  // Format job level with appropriate suffix
  const formatJobLevel = (level: number) => {
    const suffixes = ['th', 'st', 'nd', 'rd'];
    const suffix = level % 10 < 4 && Math.floor(level % 100 / 10) !== 1 
      ? suffixes[level % 10] 
      : suffixes[0];
    return `${level}${suffix} level`;
  }

  useEffect(() => {
    const fetchEmployeeData = async () => {
      setLoading(true);
      try {
        // Fetch all data in parallel
        const [gapResponse, skillsResponse, growthResponse] = await Promise.all([
          fetch(`http://localhost:8000/skillGapAnalysis/${employee.ID}`),
          fetch(`http://localhost:8000/predictSkillProficiency/${employee.ID}`),
          fetch(`http://localhost:8000/employeeGrowthFactor/${employee.ID}`)
        ]);

        if (!gapResponse.ok || !skillsResponse.ok || !growthResponse.ok) {
          throw new Error("Failed to fetch employee data");
        }

        const gapData = await gapResponse.json();
        const skillData = await skillsResponse.json();
        const growthData = await growthResponse.json();

        setSkillGapData(gapData);
        setPredictedSkills(skillData);
        setGrowthFactor(growthData);
      } catch (err) {
        setError(err instanceof Error ? err.message : "An error occurred while fetching data");
      } finally {
        setLoading(false);
      }
    };

    fetchEmployeeData();
  }, [employee.ID]);

  return (
    <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-6xl w-full h-[60vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <div>
            <h2 className="text-2xl font-bold text-slate-800">{employee.Name}</h2>
            <div className="flex items-center gap-2 mt-1">
              <p className="text-lg text-slate-600">{employee["Job Role"]}</p>
              {employee["Job Level"] && (
                <span className="text-sm text-slate-500">
                  ({formatJobLevel(employee["Job Level"])})
                </span>
              )}
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="rounded-full hover:bg-slate-100"
          >
            <X className="h-6 w-6" />
          </Button>
        </div>

        {loading ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <p>Loading employee data...</p>
          </div>
        ) : error ? (
          <div className="flex-1 flex items-center justify-center p-8">
            <p className="text-red-500">{error}</p>
          </div>
        ) : (
          <EmployeeExpandedViewContent 
            employee={employee}
            skillsArray={skillsArray}
            skillGapData={skillGapData}
            predictedSkills={predictedSkills}
            growthFactor={growthFactor}
          />
        )}
      </div>
    </div>
  );
}