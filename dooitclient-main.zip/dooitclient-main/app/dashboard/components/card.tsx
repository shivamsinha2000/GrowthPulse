// components/employee-card.tsx
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export interface Employee {
  ID: number
  Name: string
  "Job Role": string
  Department: string
  Skills: string
  "Skill 1": string
  "Skill 2": string
  "Skill 3": string
  "Skill 1 Importance": number
  "Skill 2 Importance": number
  "Skill 3 Importance": number
  "Total Experience (Years)": number
  Education: string
  "Performance Rating"?: number
  "Job Level"?: number
  "Years in Current Role"?: number
  "Certifications"?: number
  "Trainings Attended"?: number
  "Projects Worked On"?: number
  "Previous Roles"?: string
}

export function EmployeeCard({ employee }: { employee: Employee }) {
  // Extract skills as an array with importance
  const skillsArray = [
    { name: employee["Skill 1"], importance: employee["Skill 1 Importance"] },
    { name: employee["Skill 2"], importance: employee["Skill 2 Importance"] },
    { name: employee["Skill 3"], importance: employee["Skill 3 Importance"] }
  ].filter(skill => skill.name); // Filter out empty skills
  
  // Sort skills by importance (highest first)
  const topSkills = skillsArray
    .sort((a, b) => b.importance - a.importance)
    .slice(0, 3) // Take top 3 skills
    .map(skill => skill.name);
  
  // Get performance color based on rating
  const getPerformanceColor = (rating: number) => {
    if (rating >= 4) return "text-emerald-600 bg-emerald-50";
    if (rating >= 3) return "text-blue-600 bg-blue-50";
    if (rating >= 2) return "text-amber-600 bg-amber-50";
    return "text-red-600 bg-red-50";
  }
  
  // Format job level with appropriate suffix
  const formatJobLevel = (level: number) => {
    const suffixes = ['th', 'st', 'nd', 'rd'];
    const suffix = level % 10 < 4 && Math.floor(level % 100 / 10) !== 1 
      ? suffixes[level % 10] 
      : suffixes[0];
    return `${level}${suffix} level`;
  }
  
  return (
    <Card className="p-6 hover:shadow-md transition-all h-full bg-white border-slate-100 overflow-hidden">
      {/* Department Badge */}
      <div className="flex justify-between items-start mb-3">
        <Badge variant="outline" className="bg-slate-50 text-xs font-normal">
          {employee.Department}
        </Badge>
        
        {employee["Performance Rating"] && (
          <div className={`text-xs font-medium px-2 py-1 rounded-full ${getPerformanceColor(employee["Performance Rating"])}`}>
            {employee["Performance Rating"].toFixed(1)} rating
          </div>
        )}
      </div>
      
      {/* Name and Title */}
      <h3 className="font-semibold text-lg text-slate-800 leading-tight mb-1">
        {employee.Name}
      </h3>
      <div className="flex items-center gap-2 mb-3">
        <p className="text-md text-slate-600">{employee["Job Role"]}</p>
        {employee["Job Level"] && (
          <span className="text-xs text-slate-500">
            ({formatJobLevel(employee["Job Level"])})
          </span>
        )}
      </div>
      
      {/* Experience and Tenure */}
      <div className="flex items-center gap-5 mb-4 text-sm">
        <div>
          <p className="text-slate-500">Experience</p>
          <p className="font-medium text-slate-700">{employee["Total Experience (Years)"]} years</p>
        </div>
        
        {employee["Years in Current Role"] !== undefined && (
          <div>
            <p className="text-slate-500">Current Role</p>
            <p className="font-medium text-slate-700">{employee["Years in Current Role"]} years</p>
          </div>
        )}
      </div>
      
      {/* Skills */}
      <div className="mt-3 mb-4">
        <p className="text-sm font-medium mb-2 text-slate-700">Top skills:</p>
        <div className="flex flex-wrap gap-2">
          {topSkills.map((skill, index) => (
            <span 
              key={index}
              className="text-xs bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
      
      {/* Additional Info */}
      <div className="grid grid-cols-2 gap-x-3 gap-y-2 mt-4 text-xs">
        <div>
          <p className="text-slate-500">Education</p>
          <p className="font-medium text-slate-700 truncate" title={employee.Education}>
            {employee.Education}
          </p>
        </div>
        
        {employee["Certifications"] !== undefined && (
          <div>
            <p className="text-slate-500">Certifications</p>
            <p className="font-medium text-slate-700">{employee["Certifications"]}</p>
          </div>
        )}
        
        {employee["Projects Worked On"] !== undefined && (
          <div>
            <p className="text-slate-500">Projects</p>
            <p className="font-medium text-slate-700">{employee["Projects Worked On"]}</p>
          </div>
        )}
        
        {employee["Trainings Attended"] !== undefined && (
          <div>
            <p className="text-slate-500">Trainings</p>
            <p className="font-medium text-slate-700">{employee["Trainings Attended"]}</p>
          </div>
        )}
      </div>
      
      {/* Previous Roles */}
      {employee["Previous Roles"] && (
        <div className="mt-4 pt-3 border-t border-slate-100">
          <p className="text-xs text-slate-500">Previous Role</p>
          <p className="text-xs font-medium text-slate-700">{employee["Previous Roles"]}</p>
        </div>
      )}
    </Card>
  )
}