from flask import Flask, jsonify, request
from openpyxl import load_workbook
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
import xgboost as xgb
from sklearn.metrics import mean_squared_error, r2_score
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

# Load the Excel file
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
EXCEL_FILE_PATH = os.path.join(BASE_DIR, "emp1.xlsx")
JOB_REQUIREMENTS_PATH = os.path.join(BASE_DIR, "jobs.xlsx")
JOB_MARKET_INSIGHTS_PATH = os.path.join(BASE_DIR, "ai_job_market_insights.csv")
print(EXCEL_FILE_PATH)

workbook = load_workbook(EXCEL_FILE_PATH)
sheet = workbook.active


# Helper functions to interact with the Excel file
def read_excel_data():
        """Read all rows of data from the Excel sheet."""
        data = []
        for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming first row is header
            data.append({
                'ID': row[0],
                'Name': row[1],
                'Job Role': row[2],
                'Job Level': row[3],
                'Total Experience (Years)': row[4],
                'Years in Current Role': row[5],
                'Education': row[6],
                'Department': row[7],
                'Previous Roles': row[8],
                'Projects Worked On': row[9],
                'Certifications': row[10],
                'Trainings Attended': row[11],
                'Performance Rating': row[12],
                'Skills' :  ', '.join(filter(None, [row[13], row[14], row[15]])), 
                'Skill 1': row[13], 
                'Skill 2': row[14],
                'Skill 3': row[15],
                'Skill 1 Frequency': row[16],
                'Skill 2 Frequency': row[17],
                'Skill 3 Frequency': row[18],
                'Skill 1 Importance': row[19],
                'Skill 2 Importance': row[20],
                'Skill 3 Importance': row[21]
            })
        return data
def load_data():
    """Read relevant rows of data from the Excel sheet."""
    data = []
    for row in sheet.iter_rows(min_row=2, values_only=True):  # Assuming first row is header
        data.append({
            'ID': row[0],
            'Job Role': row[2],
            'Job Level': row[3],
            'Total Experience (Years)': row[4],
            'Projects Worked On': row[9],
            'Certifications': row[10],
            'Trainings Attended': row[11],
            'Performance Rating': row[12],
            'Skill 1': row[13], 
            'Skill 2': row[14],
            'Skill 3': row[15],
            'Skill 1 Frequency': row[16],
            'Skill 2 Frequency': row[17],
            'Skill 3 Frequency': row[18],
            'Skill 1 Importance': row[19],
            'Skill 2 Importance': row[20],
            'Skill 3 Importance': row[21]
        })
    return pd.DataFrame(data)

def write_to_excel(data):
    """Write a single row of data to the Excel sheet."""
    new_row = [
        data.get('ID'),
        data.get('Name'),
        data.get('Job Role'),
        data.get('Job Level'),
        data.get('Total Experience (Years)'),
        data.get('Years in Current Role'),
        data.get('Education'),
        data.get('Department'),
        data.get('Previous Roles'),
        data.get('Projects Worked On'),
        data.get('Certifications'),
        data.get('Trainings Attended'),
        data.get('Performance Rating'),
        data.get('Skill 1'),
        data.get('Skill 2'),
        data.get('Skill 3'),
        data.get('Skill 1 Frequency'),
        data.get('Skill 2 Frequency'),
        data.get('Skill 3 Frequency'),
        data.get('Skill 1 Importance'),
        data.get('Skill 2 Importance'),
        data.get('Skill 3 Importance')
    ]
    sheet.append(new_row)
    workbook.save(excel_file)
    workbook.close()  # Close file after saving

def update_excel_row(row_id, updated_data):
    """Update a specific row in the Excel sheet."""
    for row in sheet.iter_rows(min_row=2, max_row=sheet.max_row):
        if row[0].value == row_id:  # Match by ID
            column_index = {
                'Name': 2, 'Job Role': 3, 'Job Level': 4, 'Total Experience (Years)': 5,
                'Years in Current Role': 6, 'Education': 7, 'Department': 8, 'Previous Roles': 9,
                'Projects Worked On': 10, 'Certifications': 11, 'Trainings Attended': 12,
                'Performance Rating': 13, 'Skill 1': 14, 'Skill 2': 15, 'Skill 3': 16,
                'Skill 1 Frequency': 17, 'Skill 2 Frequency': 18, 'Skill 3 Frequency': 19,
                'Skill 1 Importance': 20, 'Skill 2 Importance': 21, 'Skill 3 Importance': 22
            }
            for key, value in updated_data.items():
                if key in column_index:
                    row[column_index[key] - 1].value = value
            workbook.save(EXCEL_FILE_PATH)
            workbook.close()  # Close after updating
            return True
    return False

def segregate_by_department():
    """Segregate employees based on their department while handling None values."""
    data = read_excel_data()
    department_dict = {}

    for employee in data:
        department = employee.get('Department', 'Unknown')  # Handle missing values
        if department is None:
            department = 'Unknown'  # Assign a default value

        if department not in department_dict:
            department_dict[department] = []

        department_dict[department].append(employee)

    return department_dict

def delete_excel_row(row_id):
    """Delete a specific row from the Excel sheet."""
    row_to_delete = None
    for i, row in enumerate(sheet.iter_rows(min_row=2, max_row=sheet.max_row), start=2):
        if row[0].value == row_id:
            row_to_delete = i
            break

    if row_to_delete:
        sheet.delete_rows(row_to_delete)
        workbook.save(EXCEL_FILE_PATH)
        workbook.close()  # Close after deletion
        return True
    return False
def preprocess_and_train():
    """Preprocess data and train XGBoost models for skill proficiency prediction."""
    df = load_data()

    if df is None:
        return None, None, None, None

    # One-Hot Encode 'Job Role'
    ohe = OneHotEncoder(sparse_output=False, drop='first')
    encoded_roles = ohe.fit_transform(df[['Job Role']])
    role_columns = ohe.get_feature_names_out(['Job Role'])
    df_encoded = pd.DataFrame(encoded_roles, columns=role_columns)
    df = pd.concat([df, df_encoded], axis=1).drop(columns=['Job Role'])

    # Normalize selected columns

    scaler = StandardScaler()
    df['Performance Rating']= df['Performance Rating']*2
    df['Certifications']=df['Certifications']*2
    numeric_cols = ['Total Experience (Years)']
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

# Feature Engineering
    df['Certification-to-exp Ratio'] = (df['Certifications'] + df['Trainings Attended']) / df['Total Experience (Years)']
    df['Skill 1 Score'] = (0.15*df['Skill 1 Frequency'])+(0.15*df['Skill 1 Importance'])+(2*df['Total Experience (Years)'])+(0.05*df['Projects Worked On'])+(0.05*df['Certifications'])+(0.05*df['Trainings Attended'])+(0.35*df['Performance Rating'])
    df['Skill 2 Score'] = (0.15*df['Skill 2 Frequency'])+(0.15*df['Skill 2 Importance'])+(2*df['Total Experience (Years)'])+(0.05*df['Projects Worked On'])+(0.05*df['Certifications'])+(0.05*df['Trainings Attended'])+(0.35*df['Performance Rating'])
    df['Skill 3 Score'] = (0.15*df['Skill 3 Frequency'])+(0.15*df['Skill 3 Importance'])+(2*df['Total Experience (Years)'])+(0.05*df['Projects Worked On'])+(0.05*df['Certifications'])+(0.05*df['Trainings Attended'])+(0.35*df['Performance Rating'])

    # Prepare datasets for Skill Proficiency prediction
    features = df.drop(columns=['Skill 1', 'Skill 2', 'Skill 3', 'Skill 1 Frequency', 'Skill 2 Frequency', 'Skill 3 Frequency', 'Skill 1 Importance', 'Skill 2 Importance', 'Skill 3 Importance'])

    # Train models for skill proficiency
    model_skill1, rmse1, r2_1 = train_xgboost(features, df['Skill 1 Score'])
    model_skill2, rmse2, r2_2 = train_xgboost(features, df['Skill 2 Score'])
    model_skill3, rmse3, r2_3 = train_xgboost(features, df['Skill 3 Score'])

    return model_skill1, model_skill2, model_skill3, features

# Function to train and evaluate an XGBoost model
def train_xgboost(features, target):
    X_train, X_test, y_train, y_test = train_test_split(features, target, test_size=0.2, random_state=42)
    model = xgb.XGBRegressor(objective='reg:squarederror', n_estimators=100, learning_rate=0.1, max_depth=5)
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)
    return model, rmse, r2

def read_job_requirements():
    """Load job role skill requirements from an Excel file."""
    req_workbook = load_workbook(JOB_REQUIREMENTS_PATH)
    req_sheet = req_workbook['Sheet1']

    job_requirements = {}
    for row in req_sheet.iter_rows(min_row=2, values_only=True):
        job_role = row[0]
        job_requirements[job_role] = {
            row[1]: row[2],
            row[3]: row[4],
            row[5]: row[6]
        }
    return job_requirements

def calculate_growth_factor(employee, job_data, skill_proficiencies):
    """
    Calculate the growth factor for an employee based on job data and skill proficiencies.
    """
    # Map categorical values to numerical scores
    automation_risk_map = {"Low": 1, "Medium": 2, "High": 3}
    ai_adoption_map = {"Low": 1, "Medium": 2, "High": 3}
    job_growth_map = {"Decline": 1, "Stable": 2, "Growth": 3}

    # Get job data for the employee's role
    job_role = employee['Job Role']

    filtered_job = job_data[job_data['Job_Title'] == job_role]
    if filtered_job.empty:
        # this was causing the error, 
        return 0

    # job_info = job_data[job_data['Job_Title'] == job_role].iloc[0]
    job_info = filtered_job.iloc[0]

    # Get scores for automation risk, AI adoption, and job growth
    automation_risk_score = automation_risk_map.get(job_info['Automation_Risk'], 1)
    ai_adoption_score = ai_adoption_map.get(job_info['AI_Adoption_Level'], 1)
    job_growth_score = job_growth_map.get(job_info['Job_Growth_Projection'], 1)

    # Get employee's performance rating
    performance_rating = employee['Performance Rating']

    # Calculate average skill proficiency
    skill1_proficiency = skill_proficiencies.get(employee['Skill 1'], 0)
    skill2_proficiency = skill_proficiencies.get(employee['Skill 2'], 0)
    skill3_proficiency = skill_proficiencies.get(employee['Skill 3'], 0)
    avg_skill_proficiency = (skill1_proficiency + skill2_proficiency + skill3_proficiency) / 3

    # Calculate growth factor
    growth_factor = (
        (automation_risk_score + ai_adoption_score + job_growth_score) / 3
    ) * performance_rating * avg_skill_proficiency

    return growth_factor

# API Endpoints
@app.route('/getAllData', methods=['GET'])
def get_all_data():
    data = read_excel_data()
    return jsonify(data)

@app.route('/getByDepartment', methods=['GET'])
def get_by_department():
    data = segregate_by_department()
    return jsonify(data)

@app.route('/addEmployee', methods=['POST'])
def add_employee():
    data = request.json
    if not data or 'ID' not in data or 'Name' not in data:
        return jsonify({'error': 'Invalid data'}), 400

    write_to_excel(data)
    return jsonify({'message': 'Employee added successfully'}), 200

@app.route('/updateEmployee/<int:emp_id>', methods=['POST'])
def update_employee(emp_id):
    data = request.json
    if not data:
        return jsonify({'error': 'Invalid data'}), 400

    if update_excel_row(emp_id, data):
        return jsonify({'message': 'Employee updated successfully'}), 200
    else:
        return jsonify({'error': 'Employee not found'}), 404

@app.route('/deleteEmployee/<int:emp_id>', methods=['DELETE'])
def delete_employee(emp_id):
    if delete_excel_row(emp_id):
        return jsonify({'message': 'Employee deleted successfully'}), 200
    else:
        return jsonify({'error': 'Employee not found'}), 404

@app.route('/predictSkillProficiency/<int:emp_id>', methods=['GET'])
def predict_skill_proficiency(emp_id):
    # Load models and features
    model_skill1, model_skill2, model_skill3, features = preprocess_and_train()
    if model_skill1 is None:
        return jsonify({"error": "Failed to load models or data."}), 500
    employee = next((x for x in read_excel_data() if x['ID'] == emp_id), None)
    if employee is None:
        return jsonify({"error": "Employee not found."}), 404

    skill1name = employee['Skill 1']
    skill2name = employee['Skill 2']
    skill3name = employee['Skill 3']
    # Find the employee's data
    employee_data = features[features['ID'] == emp_id]
    if employee_data.empty:
        return jsonify({"error": "Employee not found."}), 404
    # Predict skill proficiency
    skill1_proficiency = round(model_skill1.predict(employee_data)[0])
    skill2_proficiency = round(model_skill2.predict(employee_data)[0])
    skill3_proficiency = round(model_skill3.predict(employee_data)[0])

    # Return JSON response
    return jsonify({
        "Employee ID": emp_id,
        "Skills": {
            skill1name: skill1_proficiency,
            skill2name: skill2_proficiency,
            skill3name: skill3_proficiency
        }
    })

@app.route('/skillGapAnalysis/<int:emp_id>', methods=['GET'])
def skill_gap_analysis(emp_id):
    # Get employee's predicted skill proficiency
    proficiency_response = predict_skill_proficiency(emp_id)
    if 'error' in proficiency_response.json:
        return proficiency_response

    proficiency_data = proficiency_response.json
    employee = next((x for x in read_excel_data() if x['ID'] == emp_id), None)
    if employee is None:
        return jsonify({"error": "Employee not found."})

    job_role = employee['Job Role']
    job_requirements = read_job_requirements()

    if job_role not in job_requirements:
        return jsonify({"error": "Job role requirements not found."})

    # Get employee's skills and proficiencies
    employee_skills = {
        employee['Skill 1']: proficiency_data["Skills"].get(employee['Skill 1'], 0),
        employee['Skill 2']: proficiency_data["Skills"].get(employee['Skill 2'], 0),
        employee['Skill 3']: proficiency_data["Skills"].get(employee['Skill 3'], 0)
    }

    # Compare with job requirements
    skill_gaps = []
    for required_skill, required_level in job_requirements[job_role].items():
        # Search for the required skill in the employee's skills
        for emp_skill, emp_proficiency in employee_skills.items():
            if required_skill == emp_skill:
                gap = required_level - emp_proficiency
                skill_gaps.append({
                    "Skill": required_skill,
                    "Employee Proficiency": emp_proficiency,
                    "Required Proficiency": required_level,
                    "Gap": gap
                })
                break
        else:
            # If the required skill is not found in the employee's skills
            skill_gaps.append({
                "Skill": required_skill,
                "Employee Proficiency": 0,
                "Required Proficiency": required_level,
                "Gap": required_level
            })

    # Generate recommendations
    recommendations = []
    for gap in skill_gaps:
        if gap["Gap"] > 0:
            recommendations.append(f"Improve {gap['Skill']} by attending training or working on related projects.")

    return jsonify({
        "Employee ID": emp_id,
        "Job Role": job_role,
        "Skill Gaps": skill_gaps,
        "Recommendations": recommendations
    })

@app.route('/employeeGrowthFactor/<int:emp_id>', methods=['GET'])
def employee_growth_factor(emp_id):
    # Load employee data
    employee = next((x for x in read_excel_data() if x['ID'] == emp_id), None)
    if employee is None:
        return jsonify({"error": "Employee not found."}), 404

    # Load job data from CSV
    job_data = pd.read_csv(JOB_MARKET_INSIGHTS_PATH)

    # Get predicted skill proficiencies
    proficiency_response = predict_skill_proficiency(emp_id)
    if 'error' in proficiency_response.json:
        return proficiency_response

    skill_proficiencies = proficiency_response.json["Skills"]

    # Calculate growth factor
    growth_factor = calculate_growth_factor(employee, job_data, skill_proficiencies)

    return jsonify({
        "Employee ID": emp_id,
        "Job Role": employee['Job Role'],
        "Growth Factor": growth_factor
    })

@app.route('/getEmployeeStats', methods=['GET'])
def get_employee_stats():
    # Read all employee data from the Excel file
    employees = read_excel_data()
    if not employees:
        return jsonify({"error": "No employees found."}), 404

    # Store results for all employees
    all_employee_stats = []

    # Loop through each employee
    for employee in employees:
        emp_id = employee['ID']

        # Get skill gap analysis result for the employee
        skill_gap_response = skill_gap_analysis(emp_id)
        if 'error' in skill_gap_response.json:
            continue  # Skip this employee if there's an error

        # Get growth factor result for the employee
        growth_factor_response = employee_growth_factor(emp_id)
        if 'error' in growth_factor_response.json:
            continue  # Skip this employee if there's an error

        # Extract the required data
        skill_gap = skill_gap_response.json.get("Skill Gaps", [])
        growth_factor = growth_factor_response.json.get("Growth Factor", 0)

        # Add the result to the list
        all_employee_stats.append({
            "Employee ID": emp_id,
            "Skill Gaps": skill_gap,
            "Growth Factor": growth_factor
        })

    # Return the results for all employees
    return jsonify(all_employee_stats)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)