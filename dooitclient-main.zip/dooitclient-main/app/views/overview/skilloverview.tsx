import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

// TypeScript interfaces
interface SkillGap {
  "Employee Proficiency": number;
  Gap: number;
  "Required Proficiency": number;
  Skill: string;
}

interface EmployeeStats {
  "Employee ID": number;
  "Growth Factor": number;
  "Skill Gaps": SkillGap[];
}

const EmployeeSkillsHeatmap = () => {
  const [employeeData, setEmployeeData] = useState<EmployeeStats[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<string>('stacked');
  const [sortBy, setSortBy] = useState<string>('gap');

  // Define the scale - all normalized scores will sum to 10
  const NORMALIZED_SUM = 10;

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const response = await fetch('http://localhost:8000/getEmployeeStats');
        if (!response.ok) throw new Error('Failed to fetch employee data');
        const data = await response.json();
        setEmployeeData(data);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch employee data');
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Extract all unique skills from the data
  const getAllSkills = () => {
    const skillSet = new Set<string>();
    
    employeeData.forEach(employee => {
      employee["Skill Gaps"].forEach(skill => {
        skillSet.add(skill.Skill);
      });
    });
    
    return Array.from(skillSet);
  };

  // Calculate aggregated stats for skills across all employees and normalize them
  const calculateSkillStats = () => {
    const skills = getAllSkills();
    const stats = skills.map(skillName => {
      let totalGap = 0;
      let totalProficiency = 0;
      let count = 0;
      
      employeeData.forEach(employee => {
        const skillData = employee["Skill Gaps"].find(s => s.Skill === skillName);
        if (skillData) {
          totalGap += skillData.Gap;
          totalProficiency += skillData['Employee Proficiency']
          count++;
        }
      });
      
      // Calculate average values
      const avgGap = count > 0 ? totalGap / count : 0;
      const avgProficiency = count > 0 ? totalProficiency / count : 0;
      const totalValue = avgGap + avgProficiency;
      
      // Normalize values to sum to NORMALIZED_SUM while preserving ratio
      const normalizedGap = totalValue > 0 ? (avgGap / totalValue) * NORMALIZED_SUM : 0;
      const normalizedProficiency = totalValue > 0 ? (avgProficiency / totalValue) * NORMALIZED_SUM : 0;
      
      // Original percentage calculation for heatmap
      const gapPercentage = count > 0 ? (totalGap / (count * NORMALIZED_SUM)) * 100 : 0;
      
      return {
        skill: skillName,
        rawGap: avgGap,
        rawProficiency: avgProficiency,
        avgGap: normalizedGap,
        avgProficiency: normalizedProficiency,
        gapPercentage: gapPercentage,
        employeeCount: count
      };
    });
    
    // Always sort by coverage first to get top skills with most data points
    const sortedByDataPoints = stats.sort((a, b) => b.employeeCount - a.employeeCount);
    
    // Take only top 10 skills
    const top10Skills = sortedByDataPoints.slice(0, 10);
    
    // Then sort according to user selection
    if (sortBy === 'gap') {
      return top10Skills.sort((a, b) => b.avgGap - a.avgGap);
    } else if (sortBy === 'proficiency') {
      return top10Skills.sort((a, b) => a.avgProficiency - b.avgProficiency);
    } else if (sortBy === 'coverage') {
      return top10Skills; // Already sorted by coverage
    }
    
    return top10Skills;
  };

  // Get color based on value (for heatmap)
  const getHeatmapColor = (value: number, isGap: boolean) => {
    if (isGap) {
      // Red scale for gaps (darker red = bigger gap)
      const intensity = Math.min(255, Math.floor((value / NORMALIZED_SUM) * 255));
      return `rgb(${255}, ${255 - intensity}, ${255 - intensity})`;
    } else {
      // Blue scale for proficiency (darker blue = higher proficiency)
      const intensity = Math.min(255, Math.floor((value / NORMALIZED_SUM) * 255));
      return `rgb(${255 - intensity}, ${255 - intensity}, ${255})`;
    }
  };

  // Calculate growth factor statistics
  const calculateGrowthStats = () => {
    if (employeeData.length === 0) {
      return { avgGrowth: 0, maxGrowth: 0, minGrowth: 0 };
    }
    
    const growthData = employeeData.map(emp => emp["Growth Factor"]);
    const avgGrowth = growthData.reduce((sum, val) => sum + val, 0) / growthData.length;
    const maxGrowth = Math.max(...growthData);
    const minGrowth = Math.min(...growthData);
    
    return { avgGrowth, maxGrowth, minGrowth };
  };

  // Generate placeholder data for loading state
  const getPlaceholderSkillStats = () => {
    return Array(8).fill(null).map((_, index) => ({
      skill: `Skill ${index + 1}`,
      rawGap: 0,
      rawProficiency: 0,
      avgGap: 0,
      avgProficiency: 0,
      gapPercentage: 0,
      employeeCount: 0
    }));
  };

  const skillStats = loading ? getPlaceholderSkillStats() : calculateSkillStats();
  const growthStats = calculateGrowthStats();

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Organizational Skill Analysis</CardTitle>
          <div className="flex space-x-4">
            <Select value={sortBy} onValueChange={setSortBy} disabled={loading}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gap">Sort by Gap Size</SelectItem>
                <SelectItem value="proficiency">Sort by Proficiency</SelectItem>
                <SelectItem value="coverage">Sort by Coverage</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="stacked" onValueChange={setViewMode} className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="stacked">Stacked Chart</TabsTrigger>
            <TabsTrigger value="heatmap">Skills Heatmap</TabsTrigger>
          </TabsList>
          
          <TabsContent value="stacked">
            <div className="bg-gray-50 p-8 rounded-lg">
              <div className="flex flex-col md:flex-row md:gap-8">
                <div className="flex-1">
                  <h3 className="text-lg font-medium mb-2">Company-wide Skills Distribution</h3>
                  <div className="text-xs text-gray-500 mb-14 text-center">Normalized scores (sum = 10)</div>
                  
                  <div className="h-56 flex items-end justify-center gap-10">
                    {skillStats.map((stat, index) => (
                      <div key={index} className="flex flex-col items-center h-full relative" style={{width: `${60 / skillStats.length}%`, maxWidth: "60px", marginRight: "12px"}}>
                        <div className="absolute -top-12 w-full text-center">
                          <span className="text-xs font-medium">{stat.skill}</span>
                        </div>
                        <div className="w-full flex flex-col items-center justify-end h-full">
                          {/* Fixed height bars - always showing full 10 scale */}
                          <div className="w-full h-full flex flex-col-reverse">
                            {/* Gap */}
                            <div 
                              className={`w-full ${loading ? 'bg-gray-200' : 'bg-red-400'} relative`}
                              style={{
                                height: `${(stat.avgGap / NORMALIZED_SUM) * 100}%`
                              }}
                            >
                              {!loading && stat.avgGap > 0.1 && (
                                <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white">
                                  {stat.avgGap.toFixed(1)}
                                </span>
                              )}
                            </div>
                            {/* Proficiency */}
                            <div 
                              className={`w-full ${loading ? 'bg-gray-300' : 'bg-blue-500'} relative`}
                              style={{
                                height: `${(stat.avgProficiency / NORMALIZED_SUM) * 100}%`
                              }}
                            >
                              {!loading && stat.avgProficiency > 0.1 && (
                                <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-white">
                                  {stat.avgProficiency.toFixed(1)}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-center mt-6">
                    <div className="flex items-center mr-4">
                      <div className={`w-3 h-3 ${loading ? 'bg-gray-200' : 'bg-red-400'} mr-1`}></div>
                      <span className="text-xs">Skill Gap</span>
                    </div>
                    <div className="flex items-center">
                      <div className={`w-3 h-3 ${loading ? 'bg-gray-300' : 'bg-blue-500'} mr-1`}></div>
                      <span className="text-xs">Current Proficiency</span>
                    </div>
                  </div>
                </div>
                
                <div className="md:w-1/4 mt-6 md:mt-0">
                  <h3 className="text-lg font-medium mb-3">Growth Potential Overview</h3>
                  <div className="space-y-4">
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-gray-500 text-sm mb-1">Average Growth Factor</div>
                      <div className="text-xl font-bold">
                        {loading ? "—" : `${growthStats.avgGrowth.toFixed(1)}/100`}
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-gray-500 text-sm mb-1">Highest Growth</div>
                      <div className="text-xl font-bold">
                        {loading ? "—" : `${growthStats.maxGrowth.toFixed(1)}/100`}
                      </div>
                    </div>
                    <div className="bg-white p-3 rounded-lg shadow-sm">
                      <div className="text-gray-500 text-sm mb-1">Lowest Growth</div>
                      <div className="text-xl font-bold">
                        {loading ? "—" : `${growthStats.minGrowth.toFixed(1)}/100`}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="heatmap" className="w-full">
            <div className="overflow-x-auto">
              <div className="mb-1 px-2">
                <p className="text-xs text-gray-500">Top 10 skills by usage (normalized scores, sum = 10)</p>
              </div>
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="p-2 text-left">Skill</th>
                    <th className="p-2 text-center">Avg. Gap</th>
                    <th className="p-2 text-center">Current Proficiency</th>
                    <th className="p-2 text-center">Gap %</th>
                    <th className="p-2 text-center"># of Employees</th>
                  </tr>
                </thead>
                <tbody>
                  {skillStats.map((stat, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-3 font-medium">{stat.skill}</td>
                      <td className="p-3">
                        <div className="flex items-center">
                          <div 
                            className={`w-full h-6 rounded ${loading ? 'bg-gray-200' : ''}`}
                            style={!loading ? { 
                              backgroundColor: getHeatmapColor(stat.avgGap, true),
                              width: `${(stat.avgGap / NORMALIZED_SUM) * 100}%`
                            } : {}}
                          >
                            {!loading && stat.avgGap > 0.1 && (
                              <div className="text-center text-sm">
                                {stat.avgGap.toFixed(1)}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center">
                          <div 
                            className={`w-full h-6 rounded ${loading ? 'bg-gray-300' : ''}`}
                            style={!loading ? { 
                              backgroundColor: getHeatmapColor(stat.avgProficiency, false),
                              width: `${(stat.avgProficiency / NORMALIZED_SUM) * 100}%`
                            } : {}}
                          >
                            {!loading && stat.avgProficiency > 0.1 && (
                              <div className="text-center text-sm">
                                {stat.avgProficiency.toFixed(1)}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                      <td className="p-3 text-center">
                        {loading ? "—" : `${stat.gapPercentage.toFixed(1)}%`}
                      </td>
                      <td className="p-3 text-center">
                        {loading ? "—" : stat.employeeCount}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default EmployeeSkillsHeatmap;