import { NextResponse } from 'next/server'

export interface Team {
  id: string
  department: string
  teamLead: string
  employeeCount: number
  memberTitles: string[]
  currentProjects: number
}

export interface Employee {
  id: string
  name: string
  job_title: string
  skills: string[]
  experience: string
  education: string
  teamId: string
}

const mockTeams: Team[] = [
  {
    id: '1',
    department: 'Development',
    teamLead: 'Sarah Johnson',
    employeeCount: 8,
    memberTitles: ['Senior Developer', 'Frontend Engineer', 'DevOps Specialist', 'QA Engineer'],
    currentProjects: 3
  },
  {
    id: '2',
    department: 'Business Marketing',
    teamLead: 'Michael Chen',
    employeeCount: 5,
    memberTitles: ['Marketing Manager', 'Content Strategist', 'SEO Specialist', 'Social Media Coordinator'],
    currentProjects: 2
  },
  {
    id: '3',
    department: 'Customer Support',
    teamLead: 'Emma Wilson',
    employeeCount: 6,
    memberTitles: ['Support Lead', 'Technical Support', 'Customer Success Manager', 'Onboarding Specialist'],
    currentProjects: 1
  },
  {
    id: '4',
    department: 'Project Management',
    teamLead: 'David Rodriguez',
    employeeCount: 4,
    memberTitles: ['Senior PM', 'Agile Coach', 'Project Coordinator', 'Scrum Master'],
    currentProjects: 4
  },
  {
    id: '5',
    department: 'Human Resources',
    teamLead: 'Lisa Park',
    employeeCount: 3,
    memberTitles: ['HR Manager', 'Recruiter', 'Training Specialist'],
    currentProjects: 2
  }
]

export const mockEmployees: Employee[] = [
  // Development Team (teamId: '1')
  {
    id: '1',
    name: 'Sarah Johnson',
    job_title: 'Senior Developer',
    skills: ['React', 'Node.js', 'TypeScript'],
    experience: '10 years',
    education: 'MS in Computer Science',
    teamId: '1',
  },
  {
    id: '2',
    name: 'Mike Chen',
    job_title: 'Senior Developer',
    skills: ['Java', 'Spring', 'Microservices'],
    experience: '9 years',
    education: 'BS in Software Engineering',
    teamId: '1',
  },
  {
    id: '3',
    name: 'Lisa Nguyen',
    job_title: 'Frontend Engineer',
    skills: ['HTML', 'CSS', 'JavaScript'],
    experience: '5 years',
    education: 'BS in Computer Science',
    teamId: '1',
  },
  {
    id: '4',
    name: 'Robert King',
    job_title: 'Frontend Engineer',
    skills: ['Vue.js', 'CSS3', 'GraphQL'],
    experience: '4 years',
    education: 'BS in Web Development',
    teamId: '1',
  },
  {
    id: '5',
    name: 'David Brown',
    job_title: 'DevOps Specialist',
    skills: ['AWS', 'Docker', 'Kubernetes'],
    experience: '6 years',
    education: 'BS in Information Systems',
    teamId: '1',
  },
  {
    id: '6',
    name: 'Emily Davis',
    job_title: 'DevOps Specialist',
    skills: ['Azure', 'CI/CD', 'Jenkins'],
    experience: '7 years',
    education: 'BS in Information Technology',
    teamId: '1',
  },
  {
    id: '7',
    name: 'Kevin Lee',
    job_title: 'QA Engineer',
    skills: ['Selenium', 'Cypress', 'Jest'],
    experience: '5 years',
    education: 'BS in Computer Science',
    teamId: '1',
  },
  {
    id: '8',
    name: 'Angela White',
    job_title: 'QA Engineer',
    skills: ['Automation Testing', 'Mocha', 'Chai'],
    experience: '4 years',
    education: 'BS in Software Testing',
    teamId: '1',
  },

  // Business Marketing Team (teamId: '2')
  {
    id: '9',
    name: 'Michael Chen',
    job_title: 'Marketing Manager',
    skills: ['SEO', 'Content Strategy', 'Analytics'],
    experience: '8 years',
    education: 'MBA in Marketing',
    teamId: '2',
  },
  {
    id: '10',
    name: 'Rebecca Kim',
    job_title: 'Content Strategist',
    skills: ['Copywriting', 'Editorial Planning', 'Keyword Research'],
    experience: '5 years',
    education: 'BA in Communications',
    teamId: '2',
  },
  {
    id: '11',
    name: 'James Thompson',
    job_title: 'SEO Specialist',
    skills: ['Link Building', 'Google Analytics', 'HTML'],
    experience: '4 years',
    education: 'BS in Marketing',
    teamId: '2',
  },
  {
    id: '12',
    name: 'Olivia Anderson',
    job_title: 'SEO Specialist',
    skills: ['SEO Audits', 'Keyword Analysis', 'Technical SEO'],
    experience: '3 years',
    education: 'BA in Digital Marketing',
    teamId: '2',
  },
  {
    id: '13',
    name: 'Daniel Moore',
    job_title: 'Social Media Coordinator',
    skills: ['Social Media Marketing', 'Content Calendar', 'Facebook Ads'],
    experience: '2 years',
    education: 'BA in Advertising',
    teamId: '2',
  },

  // Customer Support Team (teamId: '3')
  {
    id: '14',
    name: 'Emma Wilson',
    job_title: 'Support Lead',
    skills: ['Customer Service', 'Ticket Management', 'Team Leadership'],
    experience: '7 years',
    education: 'BA in Business Administration',
    teamId: '3',
  },
  {
    id: '15',
    name: 'Alexander Garcia',
    job_title: 'Technical Support',
    skills: ['Troubleshooting', 'Linux', 'Networking'],
    experience: '4 years',
    education: 'AS in Information Technology',
    teamId: '3',
  },
  {
    id: '16',
    name: 'Samantha Scott',
    job_title: 'Technical Support',
    skills: ['Windows Server', 'VPN', 'Customer Service'],
    experience: '3 years',
    education: 'AS in Computer Science',
    teamId: '3',
  },
  {
    id: '17',
    name: 'Brian Foster',
    job_title: 'Customer Success Manager',
    skills: ['Account Management', 'Upselling', 'CRM'],
    experience: '5 years',
    education: 'BS in Business Management',
    teamId: '3',
  },
  {
    id: '18',
    name: 'Carol Martinez',
    job_title: 'Customer Success Manager',
    skills: ['Client Relationships', 'Product Training', 'Onboarding'],
    experience: '6 years',
    education: 'BA in Communications',
    teamId: '3',
  },
  {
    id: '19',
    name: 'Tiffany Bennett',
    job_title: 'Onboarding Specialist',
    skills: ['Client Implementation', 'Training Sessions', 'Documentation'],
    experience: '3 years',
    education: 'BA in Education',
    teamId: '3',
  },

  // Project Management Team (teamId: '4')
  {
    id: '20',
    name: 'David Rodriguez',
    job_title: 'Senior PM',
    skills: ['Agile Methodologies', 'Budget Management', 'Risk Assessment'],
    experience: '10 years',
    education: 'PMP Certification',
    teamId: '4',
  },
  {
    id: '21',
    name: 'Grace Taylor',
    job_title: 'Agile Coach',
    skills: ['Scrum', 'Kanban', 'Facilitation'],
    experience: '7 years',
    education: 'CSM Certification',
    teamId: '4',
  },
  {
    id: '22',
    name: 'Henry Green',
    job_title: 'Project Coordinator',
    skills: ['Scheduling', 'Resource Allocation', 'MS Project'],
    experience: '4 years',
    education: 'BS in Business Administration',
    teamId: '4',
  },
  {
    id: '23',
    name: 'Isabella Wood',
    job_title: 'Scrum Master',
    skills: ['Sprint Planning', 'JIRA', 'Team Coaching'],
    experience: '5 years',
    education: 'CSM Certification',
    teamId: '4',
  },

  // Human Resources Team (teamId: '5')
  {
    id: '24',
    name: 'Lisa Park',
    job_title: 'HR Manager',
    skills: ['Recruitment', 'Employee Relations', 'HR Policies'],
    experience: '8 years',
    education: 'MA in Human Resources',
    teamId: '5',
  },
  {
    id: '25',
    name: 'Mark Hughes',
    job_title: 'Recruiter',
    skills: ['Talent Acquisition', 'Interviewing', 'Sourcing'],
    experience: '4 years',
    education: 'BA in Psychology',
    teamId: '5',
  },
  {
    id: '26',
    name: 'Sophia Lee',
    job_title: 'Training Specialist',
    skills: ['Curriculum Development', 'Workshop Facilitation', 'E-Learning'],
    experience: '3 years',
    education: 'BA in Education',
    teamId: '5',
  },
]


export async function GET() {
  return NextResponse.json(mockTeams)
}